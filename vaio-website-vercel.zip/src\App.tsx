import { lazy } from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';
import { useAuth } from './context/AuthContext';
import { useApp } from './context/AppContext';
import Layout from './components/Layout';
import Login from './pages/Login';
import Today from './pages/Today';

const Roadmap = lazy(() => import('./pages/Roadmap'));
const Quiz = lazy(() => import('./pages/Quiz'));
const CalendarPage = lazy(() => import('./pages/CalendarPage'));
const LibraryPage = lazy(() => import('./pages/LibraryPage'));
const ToolkitPage = lazy(() => import('./pages/ToolkitPage'));
const ExamsPage = lazy(() => import('./pages/ExamsPage'));
const StatsPage = lazy(() => import('./pages/StatsPage'));
const SettingsPage = lazy(() => import('./pages/SettingsPage'));

export default function App() {
  const auth = useAuth();
  const { loading, error, clearError } = useApp();

  if (auth.status === 'loading') {
    return <div className="spinner" />;
  }

  if (auth.status === 'anon') {
    return <Login />;
  }

  return (
    <>
      {error ? (
        <div className="banner err" style={{ margin: 12 }}>
          {error}{' '}
          <button className="btn sm ghost" onClick={clearError} style={{ marginLeft: 8 }}>
            Đóng
          </button>
        </div>
      ) : null}
      {loading ? (
        <div className="spinner" />
      ) : (
        <Routes>
          <Route element={<Layout />}>
            <Route path="/" element={<Navigate to="/today" replace />} />
            <Route path="/today" element={<Today />} />
            <Route path="/roadmap" element={<Roadmap />} />
            <Route path="/quiz" element={<Quiz />} />
            <Route path="/calendar" element={<CalendarPage />} />
            <Route path="/library" element={<LibraryPage />} />
            <Route path="/toolkit" element={<ToolkitPage />} />
            <Route path="/exams" element={<ExamsPage />} />
            <Route path="/stats" element={<StatsPage />} />
            <Route path="/settings" element={<SettingsPage />} />
            <Route path="*" element={<Navigate to="/today" replace />} />
          </Route>
        </Routes>
      )}
    </>
  );
}
