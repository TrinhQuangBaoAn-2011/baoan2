import { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { QUESTIONS } from '../data/questions';
import { addDays, formatVN, todayISO } from '../lib/dates';
import { StatCard } from '../components/ui';
import { activityLevel } from '../lib/streak';

export default function StatsPage() {
  const { snap, xp, level, streak } = useApp();
  const today = todayISO();

  const tagStats = useMemo(() => {
    const qIndex = new Map(QUESTIONS.map((q) => [q.id, q]));
    const out: Record<string, { correct: number; total: number }> = {};
    for (const s of snap.quizzes) {
      if (s.kind === 'practice') continue;
      for (const d of s.details) {
        const q = qIndex.get(d.qid);
        if (!q) continue;
        for (const t of q.tags) {
          out[t] = out[t] ?? { correct: 0, total: 0 };
          out[t].total += 1;
          if (d.correct) out[t].correct += 1;
        }
      }
    }
    return out;
  }, [snap.quizzes]);

  const weakTags = Object.entries(tagStats)
    .filter(([, s]) => s.total >= 5 && s.correct / s.total < 0.6)
    .sort((a, b) => a[1].correct / a[1].total - b[1].correct / b[1].total)
    .slice(0, 6);

  const strongTags = Object.entries(tagStats)
    .filter(([, s]) => s.total >= 5 && s.correct / s.total >= 0.8)
    .sort((a, b) => b[1].correct / b[1].total - a[1].correct / a[1].total)
    .slice(0, 6);

  const totals = useMemo(() => {
    let minutes = 0;
    let days = 0;
    let quizCount = 0;
    let correct = 0;
    let answered = 0;
    for (const a of Object.values(snap.activities)) {
      minutes += a.minutes;
      days += 1;
    }
    for (const s of snap.quizzes) {
      quizCount += 1;
      correct += s.details.filter((d) => d.correct).length;
      answered += s.details.length;
    }
    return { minutes, days, quizCount, correct, answered };
  }, [snap.activities, snap.quizzes]);

  const last60 = useMemo(() => {
    const out: { date: string; minutes: number; level: number }[] = [];
    for (let i = 59; i >= 0; i--) {
      const d = addDays(today, -i);
      const a = snap.activities[d];
      out.push({ date: d, minutes: a?.minutes ?? 0, level: activityLevel(a) });
    }
    return out;
  }, [snap.activities, today]);

  const maxMin = Math.max(60, ...last60.map((d) => d.minutes));
  const recent = snap.quizzes.slice(0, 15);

  return (
    <>
      <div className="grid cols-4">
        <StatCard label="Tổng XP" value={xp.toLocaleString('vi-VN')} hint={`${level.name} · cấp ${level.level + 1}`} />
        <StatCard label="Streak hiện tại" value={`${streak.current} ngày`} hint={`Kỷ lục ${streak.longest}`} />
        <StatCard label="Ngày đã học" value={totals.days} hint={`${Math.round(totals.minutes / 60)} giờ tổng cộng`} />
        <StatCard
          label="Độ chính xác quiz"
          value={`${totals.answered ? Math.round((totals.correct / totals.answered) * 100) : 0}%`}
          hint={`${totals.quizCount} phiên · ${totals.correct}/${totals.answered} câu`}
        />
      </div>

      <div className="grid cols-2" style={{ marginTop: 14 }}>
        <div className="card">
          <h3>⏱️ 60 ngày gần nhất</h3>
          <div className="bar-chart">
            {last60.map((d) => (
              <div
                key={d.date}
                className="bar"
                title={`${formatVN(d.date)}: ${d.minutes} phút`}
                style={{
                  height: `${Math.max(3, (d.minutes / maxMin) * 100)}%`,
                  opacity: d.minutes === 0 ? 0.15 : 1,
                }}
              />
            ))}
          </div>
          <div className="tiny muted">Mỗi cột = 1 ngày (trái → phải). Cao hơn = học nhiều hơn.</div>
        </div>

        <div className="card">
          <h3>🎯 Chủ đề yếu cần tập trung</h3>
          {weakTags.length ? (
            <table>
              <thead>
                <tr>
                  <th>Tag</th>
                  <th>Đúng</th>
                  <th>Tỷ lệ</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {weakTags.map(([tag, s]) => (
                  <tr key={tag}>
                    <td>
                      <span className="badge red">{tag}</span>
                    </td>
                    <td>
                      {s.correct}/{s.total}
                    </td>
                    <td>{Math.round((s.correct / s.total) * 100)}%</td>
                    <td>
                      <Link className="btn sm" to={`/quiz?tag=${tag}`}>
                        Luyện
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <p className="muted small">Chưa đủ dữ liệu (cần ≥5 câu mỗi tag). Cứ làm quiz đều là sẽ thấy điểm yếu.</p>
          )}
          {strongTags.length ? (
            <>
              <h3 style={{ marginTop: 16 }}>💪 Chủ đề mạnh</h3>
              <div className="row">
                {strongTags.map(([tag, s]) => (
                  <span key={tag} className="badge green">
                    {tag} {Math.round((s.correct / s.total) * 100)}%
                  </span>
                ))}
              </div>
            </>
          ) : null}
        </div>
      </div>

      <div className="card">
        <h3>🧠 Phiên quiz gần đây</h3>
        {recent.length ? (
          <table>
            <thead>
              <tr>
                <th>Thời gian</th>
                <th>Loại</th>
                <th>Ngày bài</th>
                <th>Điểm</th>
                <th>Tags</th>
              </tr>
            </thead>
            <tbody>
              {recent.map((s) => (
                <tr key={s.id}>
                  <td className="small">{new Date(s.finishedAt).toLocaleString('vi-VN')}</td>
                  <td>
                    <span className={`badge ${s.kind === 'mock' ? 'purple' : s.kind === 'review' ? 'amber' : 'green'}`}>{s.kind}</span>
                  </td>
                  <td className="small">{s.dayId}</td>
                  <td>
                    <b>{s.score}</b>/{s.total}
                  </td>
                  <td className="tiny muted">{s.tags.slice(0, 4).join(', ')}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p className="muted small">
            Chưa có phiên nào. Bắt đầu với <Link to="/quiz">Quiz hôm nay</Link>.
          </p>
        )}
      </div>
    </>
  );
}
