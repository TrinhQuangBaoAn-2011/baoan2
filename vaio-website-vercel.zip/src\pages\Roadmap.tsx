import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { WEEKS } from '../data/curriculum';
import { dayDoneCount, quizDaySet } from '../lib/schedule';
import { ProgressBar, kindBadge, KIND_LABEL } from '../components/ui';

export default function Roadmap() {
  const { snap, currentDay } = useApp();
  const navigate = useNavigate();
  const [open, setOpen] = useState<number>(currentDay.week);
  const quizDays = useMemo(() => quizDaySet(snap), [snap]);

  const phases = useMemo(() => {
    const map = new Map<string, typeof WEEKS>();
    for (const w of WEEKS) {
      const arr = map.get(w.phase) ?? [];
      arr.push(w);
      map.set(w.phase, arr);
    }
    return [...map.entries()];
  }, []);

  function weekProgress(week: number) {
    const days = WEEKS.find((w) => w.week === week)?.days ?? [];
    let total = 0;
    let done = 0;
    for (const d of days) {
      total += d.tasks.length;
      done += dayDoneCount(snap, d, quizDays);
    }
    return { done, total };
  }

  return (
    <>
      <div className="card">
        <h2>Lộ trình 52 tuần</h2>
        <p className="muted small" style={{ marginTop: 0 }}>
          364 ngày học theo tiến độ thực: hoàn thành ngày nào mới mở ngày kế. Bỏ lỡ một ngày thì bài đó vẫn nằm nguyên ở
          ngày hiện tại, không bị nhảy cóc. Bấm vào một ngày để mở nhiệm vụ.
        </p>
        <div className="row">
          <span className="badge green">Học</span>
          <span className="badge blue">Lab 4h</span>
          <span className="badge amber">Checkpoint</span>
          <span className="badge purple">Mô phỏng/Mock</span>
          <span className="badge red">Đi thi</span>
        </div>
      </div>

      {phases.map(([phase, weeks]) => (
        <div key={phase} style={{ marginBottom: 18 }}>
          <h3 style={{ margin: '10px 4px' }}>{phase}</h3>
          {weeks.map((w) => {
            const prog = weekProgress(w.week);
            const isCurrent = w.week === currentDay.week;
            return (
              <div key={w.week} className={`week-block ${isCurrent ? 'current' : ''}`}>
                <div className="week-head" onClick={() => setOpen((o) => (o === w.week ? -1 : w.week))}>
                  <div>
                    <b>
                      Tuần {w.week} · {w.theme}
                    </b>
                    {isCurrent ? (
                      <span className="badge amber" style={{ marginLeft: 8 }}>
                        tuần hiện tại
                      </span>
                    ) : null}
                    <div className="tiny muted">
                      Ngày {w.days[0].index}–{w.days[6].index} · tags: {w.tags.join(', ')}
                    </div>
                  </div>
                  <div style={{ minWidth: 130 }}>
                    <ProgressBar value={prog.done} max={prog.total} />
                    <div className="tiny muted center" style={{ marginTop: 3 }}>
                      {prog.done}/{prog.total} nhiệm vụ
                    </div>
                  </div>
                </div>
                {open === w.week
                  ? w.days.map((d) => {
                      const done = dayDoneCount(snap, d, quizDays);
                      const isNow = d.id === currentDay.id;
                      return (
                        <div
                          key={d.id}
                          className={`day-row ${isNow ? 'current' : ''}`}
                          onClick={() => navigate(`/today?day=${d.id}`)}
                        >
                          <span className="date">Ngày {d.index}</span>
                          <span className={kindBadge(d.kind)}>{KIND_LABEL[d.kind]}</span>
                          <span style={{ flex: 1 }}>
                            {d.title} {isNow ? '· đang học' : ''}
                          </span>
                          <span className={`badge ${done === d.tasks.length ? 'green' : done > 0 ? 'amber' : ''}`}>
                            {done}/{d.tasks.length}
                          </span>
                        </div>
                      );
                    })
                  : null}
              </div>
            );
          })}
        </div>
      ))}
    </>
  );
}
