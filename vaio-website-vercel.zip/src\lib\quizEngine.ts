import type { DayPlan, Question, ReviewItem } from './types';
import { addDays } from './dates';

export const REVIEW_INTERVALS = [1, 3, 7, 14, 30];

export function hashStr(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function seededShuffle<T>(arr: T[], seed: number): T[] {
  const rnd = mulberry32(seed);
  const out = arr.slice();
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rnd() * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}

function matches(q: Question, tags: string[]): boolean {
  if (tags.includes('all')) return true;
  return q.tags.some((t) => tags.includes(t));
}

export interface QuizPickOptions {
  tags: string[];
  count: number;
  seed: string;
  exclude?: Set<string>;
  pool: Question[];
  preferTags?: string[];
}

/** Chọn câu hỏi ưu tiên theo tags, luôn có phương án dự phòng để đủ số lượng. */
export function pickQuestions(opts: QuizPickOptions): Question[] {
  const { tags, count, seed, pool } = opts;
  const exclude = opts.exclude ?? new Set<string>();
  const out: Question[] = [];
  const used = new Set<string>(exclude);
  const rnd = (arr: Question[]) => seededShuffle(arr.filter((q) => !used.has(q.id)), hashStr(seed) + out.length * 7919);

  const primary = pool.filter((q) => matches(q, tags));
  const secondary = pool.filter((q) => matches(q, opts.preferTags ?? []));
  const rest = pool;

  for (const source of [primary, secondary, rest]) {
    if (out.length >= count) break;
    for (const q of rnd(source)) {
      if (out.length >= count) break;
      if (used.has(q.id)) continue;
      used.add(q.id);
      out.push(q);
    }
  }
  return out.slice(0, count);
}

/** Quiz hằng ngày: 4 câu bài mới + tối đa 4 câu đến hạn ôn + phần còn lại từ kho cũ. */
export function buildDailyQuiz(
  day: DayPlan,
  pool: Question[],
  review: Record<string, ReviewItem>,
  today: string,
  mode: 'daily' | 'fast',
  studiedTags: string[],
): Question[] {
  const count = mode === 'fast' ? 5 : 10;
  const newCount = mode === 'fast' ? 2 : 4;
  const used = new Set<string>();
  const questions: Question[] = [];

  const fresh = pickQuestions({
    tags: day.tags,
    preferTags: studiedTags,
    count: newCount,
    seed: `${day.id}:${mode}:new`,
    pool,
    exclude: used,
  });
  fresh.forEach((q) => used.add(q.id));
  questions.push(...fresh);

  const due = Object.entries(review)
    .filter(([, r]) => r.due <= today)
    .sort((a, b) => (a[1].due < b[1].due ? -1 : a[1].due > b[1].due ? 1 : 0))
    .map(([qid]) => qid)
    .filter((qid) => !used.has(qid) && pool.some((q) => q.id === qid));
  const dueCount = mode === 'fast' ? Math.min(2, due.length) : Math.min(4, due.length);
  for (let i = 0; i < dueCount; i++) {
    const q = pool.find((x) => x.id === due[i]);
    if (q && !used.has(q.id)) {
      used.add(q.id);
      questions.push(q);
    }
  }

  const remaining = count - questions.length;
  if (remaining > 0) {
    const fill = pickQuestions({
      tags: day.tags,
      preferTags: studiedTags,
      count: remaining,
      seed: `${day.id}:${mode}:fill`,
      pool,
      exclude: used,
    });
    fill.forEach((q) => {
      used.add(q.id);
      questions.push(q);
    });
  }
  return questions.slice(0, count);
}

export function buildReviewQuiz(pool: Question[], review: Record<string, ReviewItem>, today: string, max = 20): Question[] {
  const due = Object.entries(review)
    .filter(([, r]) => r.due <= today)
    .sort((a, b) => (a[1].due < b[1].due ? -1 : 1))
    .slice(0, max)
    .map(([qid]) => pool.find((q) => q.id === qid))
    .filter((q): q is Question => Boolean(q));
  return due;
}

export function buildPracticeQuiz(pool: Question[], tags: string[], count: number, seed: string): Question[] {
  return pickQuestions({ tags, count, seed, pool });
}

export function buildMockQuiz(pool: Question[], count: number, seed: string): Question[] {
  return seededShuffle(pool, hashStr(seed)).slice(0, Math.min(count, pool.length));
}

const norm = (s: string) =>
  s
    .toLowerCase()
    .trim()
    .replace(/[.,;:!?"'`]/g, '')
    .replace(/\s+/g, ' ');

export function checkAnswer(q: Question, given: string[]): boolean {
  if (q.type === 'mcq') {
    return given.length === 1 && String(q.a) === given[0];
  }
  if (q.type === 'multi') {
    const correct = (q.a as number[]).map(String).sort();
    const g = given.slice().sort();
    return correct.length === g.length && correct.every((x, i) => x === g[i]);
  }
  const accepted = (q.a as string[]).map(norm);
  return given.some((g) => accepted.includes(norm(g)));
}

/** Khi làm đúng trong ôn tập thì giãn cách tăng dần; sai thì reset. */
export function nextReview(item: ReviewItem | undefined, correct: boolean, today: string): ReviewItem {
  if (!item) {
    return correct
      ? { due: addDays(today, REVIEW_INTERVALS[0]), intervalIdx: 0, wrong: 0, last: 'right' }
      : { due: addDays(today, 1), intervalIdx: 0, wrong: 1, last: 'wrong' };
  }
  if (correct) {
    const idx = Math.min(item.intervalIdx + 1, REVIEW_INTERVALS.length - 1);
    return { due: addDays(today, REVIEW_INTERVALS[idx]), intervalIdx: idx, wrong: item.wrong, last: 'right' };
  }
  return { due: addDays(today, 1), intervalIdx: 0, wrong: item.wrong + 1, last: 'wrong' };
}

export function studiedTagsUpTo(days: DayPlan[], currentIndex: number): string[] {
  const tags = new Set<string>();
  for (const d of days) {
    if (d.index < currentIndex) d.tags.forEach((t) => tags.add(t));
  }
  return [...tags];
}
