import type { ReactNode } from 'react';

export function Sticker({
  emoji,
  label,
  size = 'md',
  className = '',
}: {
  emoji: string;
  label?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg';
  className?: string;
}) {
  return (
    <span
      className={`sticker sticker-${size} ${className}`.trim()}
      role={label ? 'img' : undefined}
      aria-label={label}
      aria-hidden={label ? undefined : true}
    >
      {emoji}
    </span>
  );
}

export function ProgressBar({ value, max }: { value: number; max: number }) {
  const pct = max > 0 ? Math.min(100, Math.round((value / max) * 100)) : 0;
  return (
    <div className="pbar" title={`${value}/${max}`}>
      <div style={{ width: `${pct}%` }} />
    </div>
  );
}

export function StatCard({ label, value, hint }: { label: string; value: ReactNode; hint?: string }) {
  return (
    <div className="card" style={{ marginBottom: 0 }}>
      <div className="muted small">{label}</div>
      <div style={{ fontSize: 26, fontWeight: 800, margin: '4px 0' }}>{value}</div>
      {hint ? <div className="tiny muted">{hint}</div> : null}
    </div>
  );
}

export function Banner({ kind, children }: { kind: 'info' | 'warn' | 'err'; children: ReactNode }) {
  return <div className={`banner ${kind}`}>{children}</div>;
}

export function Modal({ onClose, children }: { onClose: () => void; children: ReactNode }) {
  return (
    <div className="modal-back" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        {children}
      </div>
    </div>
  );
}

export const KIND_LABEL: Record<string, string> = {
  lesson: 'Học',
  lab: 'Lab',
  checkpoint: 'Checkpoint',
  mock: 'Mock',
  rest: 'Nghỉ',
  exam: 'THI',
};

export function kindBadge(kind: string): string {
  switch (kind) {
    case 'exam':
      return 'badge red';
    case 'mock':
      return 'badge purple';
    case 'lab':
      return 'badge blue';
    case 'checkpoint':
      return 'badge amber';
    case 'rest':
      return 'badge';
    default:
      return 'badge green';
  }
}
