import { useEffect, useMemo, useRef, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { QUESTIONS, ALL_TAGS } from '../data/questions';
import { DAYS } from '../data/curriculum';
import {
  buildDailyQuiz,
  buildMockQuiz,
  buildPracticeQuiz,
  buildReviewQuiz,
  checkAnswer,
  studiedTagsUpTo,
} from '../lib/quizEngine';
import type { Question, QuizAnswer, QuizKind, QuizSession } from '../lib/types';
import { todayISO } from '../lib/dates';
import { ProgressBar, Sticker } from '../components/ui';

type Phase = 'setup' | 'running' | 'done';

function newId(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) return crypto.randomUUID();
  return `s-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}

function answerText(q: Question): string {
  if (q.type === 'mcq') return q.options?.[q.a as number] ?? String(q.a);
  if (q.type === 'multi') return (q.a as number[]).map((i) => q.options?.[i]).join(' · ');
  return (q.a as string[]).join(' / ');
}

export default function Quiz() {
  const { snap, finishQuiz, currentDay } = useApp();
  const [params] = useSearchParams();
  const [phase, setPhase] = useState<Phase>('setup');
  const [kind, setKind] = useState<QuizKind>('daily');
  const [questions, setQuestions] = useState<Question[]>([]);
  const [idx, setIdx] = useState(0);
  const [answers, setAnswers] = useState<QuizAnswer[]>([]);
  const [given, setGiven] = useState<string[]>([]);
  const [fillText, setFillText] = useState('');
  const [revealed, setRevealed] = useState(false);
  const [awarded, setAwarded] = useState(0);
  const [practiceTag, setPracticeTag] = useState<string>(() => params.get('tag') ?? 'python');
  const [mockPreset, setMockPreset] = useState<{ n: number; min: number }>({ n: 30, min: 45 });
  const [remaining, setRemaining] = useState<number | null>(null);
  const [elapsed, setElapsed] = useState(0);
  const startRef = useRef<number>(0);
  const answersRef = useRef<QuizAnswer[]>([]);
  const submittedRef = useRef(false);
  const dayId = params.get('day') ?? currentDay.id;
  const day = useMemo(() => DAYS.find((d) => d.id === dayId) ?? currentDay, [dayId, currentDay]);
  const today = todayISO();

  const dueCount = useMemo(() => Object.values(snap.review).filter((r) => r.due <= today).length, [snap.review, today]);

  function start(k: QuizKind, qs: Question[], mockMinutes: number | null = null) {
    if (qs.length === 0) return;
    setKind(k);
    setQuestions(qs);
    setIdx(0);
    setAnswers([]);
    setGiven([]);
    setFillText('');
    setRevealed(false);
    setAwarded(0);
    setRemaining(mockMinutes);
    submittedRef.current = false;
    startRef.current = Date.now();
    setElapsed(0);
    setPhase('running');
  }

  function startFromParams() {
    const mode = (params.get('mode') ?? 'daily') as QuizKind;
    if (mode === 'review') {
      start('review', buildReviewQuiz(QUESTIONS, snap.review, today, 20));
    } else if (mode === 'mock') {
      start('mock', buildMockQuiz(QUESTIONS, 30, `${Date.now()}`), 45 * 60);
    } else if (mode === 'fast') {
      start('fast', buildDailyQuiz(day, QUESTIONS, snap.review, today, 'fast', studiedTagsUpTo(DAYS, day.index)));
    } else {
      start('daily', buildDailyQuiz(day, QUESTIONS, snap.review, today, 'daily', studiedTagsUpTo(DAYS, day.index)));
    }
  }

  useEffect(() => {
    if (params.get('mode')) startFromParams();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // đồng hồ chạy
  useEffect(() => {
    if (phase !== 'running') return;
    const t = window.setInterval(() => {
      setElapsed(Math.floor((Date.now() - startRef.current) / 1000));
      if (remaining !== null) {
        setRemaining((r) => (r === null ? r : Math.max(0, r - 1)));
      }
    }, 1000);
    return () => window.clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase, remaining !== null]);

  // Hết giờ mô phỏng: tự nộp bài (không dùng setState trong updater để tránh bug)
  useEffect(() => {
    if (phase === 'running' && remaining === 0) {
      void submitAll(answersRef.current);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [remaining, phase]);

  useEffect(() => {
    answersRef.current = answers;
  }, [answers]);

  const current = questions[idx];

  function toggleOption(i: number) {
    if (revealed) return;
    if (kind === 'mock') {
      if (current.type === 'multi') {
        setGiven((g) => (g.includes(String(i)) ? g.filter((x) => x !== String(i)) : [...g, String(i)]));
      } else {
        setGiven([String(i)]);
      }
      return;
    }
    if (current.type === 'multi') {
      setGiven((g) => (g.includes(String(i)) ? g.filter((x) => x !== String(i)) : [...g, String(i)]));
    } else {
      const g = [String(i)];
      setGiven(g);
      setRevealed(true);
      setAnswers((a) => {
        const rest = a.filter((x) => x.qid !== current.id);
        return [...rest, { qid: current.id, correct: checkAnswer(current, g), given: g }];
      });
    }
  }

  function submitOpenAnswer() {
    if (!current || revealed) return;
    const g = current.type === 'fill' ? [fillText] : given;
    if (g.length === 0 || (current.type === 'fill' && !fillText.trim())) return;
    setRevealed(true);
    setAnswers((a) => {
      const rest = a.filter((x) => x.qid !== current.id);
      return [...rest, { qid: current.id, correct: checkAnswer(current, g), given: g }];
    });
  }

  function next() {
    if (!current) return;
    if (revealed) {
      setRevealed(false);
      setGiven([]);
      setFillText('');
      if (idx + 1 >= questions.length) {
        void submitAll(answers);
      } else {
        setIdx((i) => i + 1);
      }
      return;
    }
    // mock: ghi nhận rồi sang câu kế, không lộ đáp án
    const g = current.type === 'fill' ? [fillText] : given;
    if (g.length === 0 || (current.type === 'fill' && !fillText.trim())) return;
    const rec: QuizAnswer = { qid: current.id, correct: checkAnswer(current, g), given: g };
    const nextAnswers = [...answers.filter((x) => x.qid !== current.id), rec];
    setAnswers(nextAnswers);
    setGiven([]);
    setFillText('');
    if (idx + 1 >= questions.length) {
      void submitAll(nextAnswers);
    } else {
      setIdx((i) => i + 1);
    }
  }

  async function submitAll(finalAnswers: QuizAnswer[]) {
    if (phase !== 'running' || submittedRef.current) return;
    submittedRef.current = true;
    const score = finalAnswers.filter((a) => a.correct).length;
    const session: QuizSession = {
      id: newId(),
      dayId: day.id,
      kind,
      startedAt: new Date(startRef.current).toISOString(),
      finishedAt: new Date().toISOString(),
      score,
      total: questions.length,
      tags: [...new Set(questions.flatMap((q) => q.tags))],
      details: questions.map((q) => finalAnswers.find((a) => a.qid === q.id) ?? { qid: q.id, correct: false, given: [] }),
    };
    const minutes = Math.max(1, Math.round((Date.now() - startRef.current) / 60000));
    const xp = await finishQuiz(session, minutes);
    setAwarded(xp);
    setAnswers(session.details);
    setPhase('done');
  }

  // ---------------- SETUP ----------------
  if (phase === 'setup') {
    return (
      <>
        <div className="card">
          <h2>🧠 Quiz</h2>
          <p className="muted small" style={{ marginTop: 0 }}>
            Ngày {day.index}/364 — {day.title}. Mỗi ngày làm ít nhất 1 quiz (10 câu). XP quiz chỉ cộng 1 lần/ngày mỗi loại,
            còn làm lại chỉ để ôn — không bao giờ tăng điểm ảo.
          </p>
        </div>

        <div className="grid cols-2">
          <div className="card">
            <h3>Quiz hôm nay (10 câu)</h3>
            <p className="small muted">4 câu bài mới hôm nay + câu đến hạn ôn + câu cũ ngẫu nhiên.</p>
            <button className="btn primary" onClick={startFromParams}>
              Bắt đầu quiz ngày
            </button>
            <div style={{ height: 10 }} />
            <button
              className="btn"
              onClick={() => start('fast', buildDailyQuiz(day, QUESTIONS, snap.review, today, 'fast', studiedTagsUpTo(DAYS, day.index)))}
            >
              Quiz nhanh (5 câu)
            </button>
          </div>

          <div className="card">
            <h3>Ôn tập lặp lại ngắt quãng</h3>
            <p className="small muted">
              {dueCount > 0
                ? `Có ${dueCount} câu đến hạn ôn hôm nay. Sai sẽ quay lại sau 1 ngày, đúng sẽ giãn dần 3–7–14–30 ngày.`
                : 'Hôm nay chưa có câu nào đến hạn. Làm quiz ngày để tạo hàng đợi ôn.'}
            </p>
            <button
              className="btn"
              disabled={dueCount === 0}
              onClick={() => start('review', buildReviewQuiz(QUESTIONS, snap.review, today, 20))}
            >
              Ôn {dueCount} câu đến hạn
            </button>
          </div>

          <div className="card">
            <h3>Luyện theo chủ đề</h3>
            <label className="field">
              <span>Chủ đề</span>
              <select value={practiceTag} onChange={(e) => setPracticeTag(e.target.value)}>
                {ALL_TAGS.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            </label>
            <button
              className="btn"
              onClick={() =>
                start('practice', buildPracticeQuiz(QUESTIONS, [practiceTag], 10, `${practiceTag}-${Date.now()}`))
              }
            >
              Luyện 10 câu (không XP)
            </button>
          </div>

          <div className="card">
            <h3>Mô phỏng có bấm giờ</h3>
            <label className="field">
              <span>Chế độ</span>
              <select
                value={`${mockPreset.n}-${mockPreset.min}`}
                onChange={(e) => {
                  const [n, min] = e.target.value.split('-').map(Number);
                  setMockPreset({ n, min });
                }}
              >
                <option value="10-15">Mini: 10 câu / 15 phút</option>
                <option value="30-45">Nhỏ: 30 câu / 45 phút</option>
                <option value="60-90">Vừa: 60 câu / 90 phút</option>
                <option value="100-120">Chuẩn VOAI: 100 câu / 120 phút</option>
              </select>
            </label>
            <button
              className="btn"
              onClick={() => {
                start('mock', buildMockQuiz(QUESTIONS, mockPreset.n, `${Date.now()}`), mockPreset.min * 60);
              }}
            >
              Vào phòng mô phỏng
            </button>
          </div>
        </div>
      </>
    );
  }

  // ---------------- DONE ----------------
  if (phase === 'done') {
    const score = answers.filter((a) => a.correct).length;
    const wrong = answers.filter((a) => !a.correct);
    return (
      <>
        <div className="card center">
          <Sticker emoji={score / Math.max(1, questions.length) >= 0.8 ? '🎉' : '💪'} size="lg" label="Kết quả quiz" />
          <h2>{score / Math.max(1, questions.length) >= 0.8 ? 'Tuyệt vời!' : 'Cố lên!'}</h2>
          <div className="score-big">
            {score}/{questions.length}
          </div>
          <p className="muted small">
            {awarded > 0 ? `+${awarded} XP` : 'Không thêm XP (loại này đã được tính hôm nay hoặc là chế độ luyện tập)'} ·{' '}
            {Math.max(1, Math.round(elapsed / 60))} phút
          </p>
          <div className="row" style={{ justifyContent: 'center' }}>
            <Link className="btn primary" to="/today">
              Về trang Hôm nay
            </Link>
            <Link className="btn" to="/quiz">
              Làm quiz khác
            </Link>
          </div>
        </div>

        {wrong.length > 0 ? (
          <div className="card">
            <h3>📝 {wrong.length} câu cần chữa</h3>
            {wrong.map((w) => {
              const q = QUESTIONS.find((x) => x.id === w.qid);
              if (!q) return null;
              return (
                <div key={w.qid} style={{ borderTop: '1px solid var(--line)', paddingTop: 10, marginTop: 10 }}>
                  <b className="small">{q.q}</b>
                  <div className="small" style={{ marginTop: 4 }}>
                    ✅ Đáp án: <b>{answerText(q)}</b>
                  </div>
                  <div className="tiny muted">{q.why}</div>
                </div>
              );
            })}
            <p className="tiny muted" style={{ marginBottom: 0 }}>
              Các câu sai đã được đưa vào hàng đợi ôn tập (quay lại sau 1 ngày).
            </p>
          </div>
        ) : (
          <div className="card center">Không có câu sai — quá đỉnh! Thử tăng độ khó bằng mô phỏng nhé.</div>
        )}
      </>
    );
  }

  // ---------------- RUNNING ----------------
  if (!current) return <div className="card">Không có câu hỏi phù hợp. <Link to="/quiz">Quay lại</Link></div>;
  const correctSoFar = answers.filter((a) => a.correct).length;
  const isMock = kind === 'mock';

  return (
    <>
      <div className="card">
        <div className="row between">
          <span className="small muted">
            Câu {idx + 1}/{questions.length} · {isMock ? 'Mô phỏng (không hiện đáp án)' : 'Học tương tác'}
          </span>
          <span className="small">
            {isMock && remaining !== null ? `⏳ ${String(Math.floor(remaining / 60)).padStart(2, '0')}:${String(remaining % 60).padStart(2, '0')}` : `Đúng ${correctSoFar}`}
          </span>
        </div>
        <div style={{ marginTop: 6 }}>
          <ProgressBar value={idx + (revealed ? 1 : 0)} max={questions.length} />
        </div>
      </div>

      <div className="card">
        <div className="row small" style={{ marginBottom: 8 }}>
          {current.tags.map((t) => (
            <span key={t} className="badge blue">
              {t}
            </span>
          ))}
          {isMock ? <span className="badge purple">mock</span> : null}
        </div>
        <h3 style={{ marginTop: 0 }}>{current.q}</h3>

        {current.type === 'fill' ? (
          <input
            className="input"
            placeholder="Nhập đáp án…"
            value={fillText}
            disabled={revealed}
            onChange={(e) => setFillText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') (isMock || revealed ? next() : submitOpenAnswer());
            }}
            autoFocus
          />
        ) : (
          current.options?.map((op, i) => {
            const chosen = given.includes(String(i));
            const isCorrect = current.type === 'multi' ? (current.a as number[]).includes(i) : current.a === i;
            let cls = 'q-option';
            if (chosen) cls += ' selected';
            if (revealed && isCorrect) cls += ' correct';
            if (revealed && chosen && !isCorrect) cls += ' wrong';
            return (
              <button key={i} className={cls} onClick={() => toggleOption(i)}>
                <b style={{ marginRight: 8 }}>{String.fromCharCode(65 + i)}.</b>
                {op}
              </button>
            );
          })
        )}

        {revealed ? (
          <div className={`feedback ${answers.find((a) => a.qid === current.id)?.correct ? 'ok' : 'bad'}`}>
            <b>{answers.find((a) => a.qid === current.id)?.correct ? '✅ Chính xác!' : '❌ Chưa đúng.'}</b>{' '}
            Đáp án đúng: <b>{answerText(current)}</b>
            <div className="small" style={{ marginTop: 6 }}>
              {current.why}
            </div>
          </div>
        ) : null}

        <div className="row" style={{ marginTop: 12, justifyContent: 'flex-end' }}>
          {!revealed && current.type !== 'mcq' ? (
            <button className="btn primary" onClick={isMock ? next : submitOpenAnswer} disabled={current.type === 'multi' ? given.length === 0 : !fillText.trim()}>
              {isMock ? 'Câu tiếp →' : 'Trả lời'}
            </button>
          ) : null}
          {revealed || (isMock && current.type === 'mcq') ? (
            <button
              className="btn primary"
              onClick={next}
              disabled={isMock && !revealed && given.length === 0}
            >
              {idx + 1 >= questions.length ? 'Nộp bài' : 'Câu tiếp →'}
            </button>
          ) : null}
          <button className="btn ghost" onClick={() => void submitAll(answersRef.current)}>
            Kết thúc sớm
          </button>
        </div>
      </div>
    </>
  );
}
