import type { DayKind, DayPlan, Task } from '../lib/types';
import { DEFAULT_START_DATE } from '../lib/types';
import { addDays, diffDays } from '../lib/dates';

export const START_DATE = DEFAULT_START_DATE;

interface RawDay {
  t: string;
  k?: DayKind;
}

interface WeekSpec {
  week: number;
  phase: string;
  theme: string;
  tags: string[];
  days: (string | RawDay)[];
}

function w(week: number, phase: string, theme: string, tags: string[], days: (string | RawDay)[]): WeekSpec {
  return { week, phase, theme, tags, days };
}

const WEEKS_RAW: WeekSpec[] = [
  w(1, 'P0 – Khởi động', 'Python nhập môn & setup', ['python'], [
    'Setup máy, Python, VS Code, Colab, GitHub; tạo tài khoản Kaggle',
    'Biến, kiểu dữ liệu, print/input, ép kiểu',
    'Toán tử, so sánh, if/elif/else',
    'Vòng lặp for/while, range, break/continue',
    'Hàm, tham số, return, scope',
    'Hoàn thiện môi trường + 15 bài tập Python',
    'Mini app "máy tính bỏ túi" + checkpoint 20 câu',
  ]),
  w(2, 'P0 – Khởi động', 'Cấu trúc dữ liệu Python', ['python'], [
    'List, tuple, indexing, slicing',
    'Dict, set, vòng lặp qua dict',
    'String & phương thức chuỗi',
    'List comprehension, file I/O',
    'Xử lý lỗi try/except, import/module',
    '20 bài tập thuật toán cơ bản',
    'Project "flashcard CLI"',
  ]),
  w(3, 'P1 – Nền tảng', 'NumPy', ['numpy'], [
    'NumPy: array, shape, dtype',
    'Indexing/slicing mảng',
    'Vectorization & broadcasting',
    'ufunc, axis, aggregate',
    'Random, lưu/đọc .npy',
    '20 bài tập NumPy',
    'Phân tích điểm thi bằng NumPy',
  ]),
  w(4, 'P1 – Nền tảng', 'Pandas', ['pandas'], [
    'Pandas Series/DataFrame',
    'Đọc CSV, loc/iloc',
    'Filter, sort, value_counts',
    'groupby, agg',
    'Merge/join, pivot, missing data',
    'EDA dataset Titanic',
    'Bài tập Pandas tổng hợp',
  ]),
  w(5, 'P1 – Nền tảng', 'Trực quan hoá dữ liệu', ['viz'], [
    'Matplotlib: line/bar/scatter',
    'Subplots, style, legend',
    'Seaborn distributions',
    'Seaborn relation/categorical',
    'Heatmap + quy trình EDA',
    'Hoàn chỉnh EDA Titanic',
    'Báo cáo EDA notebook',
  ]),
  w(6, 'P1 – Nền tảng', 'Git, Jupyter, công cụ', ['git'], [
    'Git cơ bản: commit, branch',
    'GitHub: README, push/pull',
    'Jupyter workflow, venv, pip',
    'Kaggle & Colab workflow',
    'Debug, đọc traceback, tìm lỗi',
    'Đưa project lên GitHub',
    { t: 'Ôn Python + mock 30 câu', k: 'mock' },
  ]),
  w(7, 'P1 – Nền tảng', 'Đại số tuyến tính', ['math-la'], [
    'Vector, ma trận, phép toán',
    'Dot, transpose, ý nghĩa hình học',
    'Determinant, inverse (ý nghĩa)',
    'Span, độc lập tuyến tính, rank',
    'Trị riêng, vector riêng (trực giác)',
    'Bài tập đại số tuyến tính bằng NumPy',
    'Ôn LA + checkpoint',
  ]),
  w(8, 'P1 – Nền tảng', 'Giải tích & tối ưu', ['math-calc'], [
    'Đạo hàm, ý nghĩa, quy tắc',
    'Đạo hàm riêng',
    'Chain rule',
    'Gradient, Jacobian (trực giác)',
    'Tối ưu, điểm yên ngựa, convex',
    'Gradient descent 1 biến từ số 0',
    'Linear regression từ số 0',
  ]),
  w(9, 'P1 – Nền tảng', 'Xác suất', ['math-prob'], [
    'Xác suất cơ bản, không gian mẫu',
    'Biến ngẫu nhiên, phân phối',
    'Kỳ vọng, phương sai',
    'Bayes, xác suất có điều kiện',
    'MLE trực giác',
    'Mô phỏng xác suất bằng code',
    'Ôn xác suất + checkpoint',
  ]),
  w(10, 'P1 – Nền tảng', 'Thống kê & lý thuyết thông tin', ['math-stats'], [
    'Thống kê mô tả',
    'Tương quan, scatter matrix',
    'Lấy mẫu, CLT',
    'Ước lượng, khoảng tin cậy',
    'Entropy, cross-entropy, KL',
    'Bài tập thống kê',
    { t: 'Tổng ôn Toán + mock 40 câu', k: 'mock' },
  ]),
  w(11, 'P2 – ML cổ điển', 'Nhập môn Machine Learning', ['ml-basics'], [
    'ML là gì, các nhóm bài toán',
    'Train/val/test, data leakage',
    'Bias–variance, under/overfit',
    'Quy trình ML end-to-end',
    'scikit-learn API, pipeline cơ bản',
    'Notebook ML chuẩn',
    'Checkpoint + quiz',
  ]),
  w(12, 'P2 – ML cổ điển', 'Hồi quy', ['linreg'], [
    'Linear regression, OLS',
    'Gradient descent & variants',
    'Polynomial regression',
    'Metrics hồi quy (MSE/MAE/R²)',
    'Feature scaling, chuẩn hoá',
    'House Prices mini-project',
    'Viết lại từ scratch',
  ]),
  w(13, 'P2 – ML cổ điển', 'Phân loại & metrics', ['logreg'], [
    'Logistic regression, sigmoid',
    'Decision boundary, xác suất dự đoán',
    'Metrics phân loại',
    'Confusion matrix',
    'Precision/Recall/F1, trade-off',
    'Titanic baseline',
    'Phân tích lỗi',
  ]),
  w(14, 'P2 – ML cổ điển', 'Regularization & tuning', ['reg'], [
    'Regularization L1/L2',
    'Ridge, Lasso, ElasticNet',
    'Cross-validation (K-fold)',
    'Grid/Random search',
    'Optuna, tuning tự động',
    'Tune Titanic',
    'Báo cáo + checkpoint',
  ]),
  w(15, 'P2 – ML cổ điển', 'Tree & ensemble', ['trees'], [
    'KNN',
    'Decision Tree (entropy/Gini)',
    'Random Forest, bagging',
    'Boosting: GBM/XGBoost/LightGBM',
    'Feature importance, SHAP cơ bản',
    'So sánh 5 mô hình',
    'Ensemble nhỏ',
  ]),
  w(16, 'P2 – ML cổ điển', 'SVM & kernel', ['svm'], [
    'SVM: margin, hard/soft',
    'Kernel trick, RBF',
    'Tuning SVM (C, gamma)',
    'SVM vs tree, khi nào dùng',
    'Calibration, decision scores',
    'SVM trên dataset ảnh nhỏ',
    'Tổng ôn ML (phần 1)',
  ]),
  w(17, 'P2 – ML cổ điển', 'Học không giám sát', ['unsup'], [
    'KMeans, elbow, silhouette',
    'Hierarchical, DBSCAN, spectral',
    'PCA: toán & ứng dụng',
    't-SNE, UMAP',
    'Chọn số chiều, nén dữ liệu',
    'Giảm chiều + visualize',
    'Project clustering',
  ]),
  w(18, 'P2 – ML cổ điển', 'Feature engineering & đánh giá', ['features', 'metrics'], [
    'Feature engineering (số/chuỗi/ảnh)',
    'Mất cân bằng: SMOTE, class weight',
    'ROC, PR, AUC',
    'Dữ liệu chuỗi/ảnh nhập môn',
    'Lưu model joblib, tái sử dụng',
    'Kaggle submission đầu tiên',
    'Checkpoint + toolkit',
  ]),
  w(19, 'P2 – ML cổ điển', 'Tổng ôn ML + nhập môn PyTorch', ['ml-basics', 'metrics', 'pytorch'], [
    'Tổng ôn ML + bảng công thức',
    'Mock 60 câu, chữa lỗi',
    'Tổng ôn ML chỉ với flashcard',
    'Nhập môn PyTorch: tensor, autograd',
    'Kế hoạch Phase 3 + quiz tổng',
    'Mock 100 câu kiểu VOAI',
    { t: 'Chữa đề + lập kế hoạch Phase 3', k: 'rest' },
  ]),
  w(20, 'P3 – Deep Learning', 'PyTorch cơ bản', ['pytorch'], [
    'Tensor PyTorch, shape, dtype',
    'Autograd, tính gradient',
    'Dataset, DataLoader',
    'CPU vs GPU, dùng Colab',
    'Lưu/load tensor, seed, reproducibility',
    'Chuyển bài ML cũ sang PyTorch',
    'Checkpoint',
  ]),
  w(21, 'P3 – Deep Learning', 'Mạng nơ-ron', ['nn'], [
    'Perceptron, neuron',
    'MLP, kiến trúc mạng',
    'Forward propagation',
    'Loss: MSE/MAE/CE/BCE',
    'Backprop thủ công',
    'MLP from scratch (không PyTorch)',
    'So sánh với PyTorch',
  ]),
  w(22, 'P3 – Deep Learning', 'Tối ưu hoá', ['dl'], [
    'Training loop chuẩn',
    'SGD, mini-batch',
    'Momentum, Nesterov',
    'Adam, AdamW',
    'Learning rate schedule, warmup',
    'Benchmark optimizer',
    'Checkpoint',
  ]),
  w(23, 'P3 – Deep Learning', 'Chống overfit & ổn định', ['dl'], [
    'Dropout',
    'Weight decay, early stopping',
    'Weight initialization',
    'BatchNorm, LayerNorm',
    'Hyperparameter tuning cho DL',
    'Pipeline chống overfit',
    'Checkpoint',
  ]),
  w(24, 'P3 – Deep Learning', 'Embedding, autoencoder, fine-tune', ['dl'], [
    'Embeddings: text/image/audio',
    'Pooling: max/avg/global',
    'Autoencoder',
    'Save/load model, inference',
    'Fine-tune full vs PEFT (LoRA)',
    'Visualize embedding (UMAP)',
    'Fine-tune mô hình nhỏ',
  ]),
  w(25, 'P3 – Deep Learning', 'Attention & Transformer', ['attention'], [
    'Attention là gì',
    'Self-attention, Q/K/V',
    'Positional encoding',
    'Multi-head attention',
    'Transformer block, kiến trúc',
    'Viết transformer mini',
    { t: 'Mock DL 60 câu', k: 'mock' },
  ]),
  w(26, 'P4 – Computer Vision', 'CNN & augmentation', ['cv'], [
    'Convolution, filter, kernel',
    'Padding, stride, pooling',
    'Kiến trúc CNN kinh điển',
    'Augmentation (Albumentations)',
    'Đọc ảnh, batch, normalize',
    'CNN trên CIFAR-10',
    'Checkpoint + lỗi thường gặp',
  ]),
  w(27, 'P4 – Computer Vision', 'Transfer learning', ['cv'], [
    'Transfer learning là gì',
    'ResNet, EfficientNet',
    'ViT & thư viện timm',
    'Fine-tune model ảnh',
    'Phân tích lỗi, confusion matrix ảnh',
    'Fine-tune dataset ảnh thật',
    'Checkpoint',
  ]),
  w(28, 'P4 – Computer Vision', 'Object detection', ['cv'], [
    'Object detection: khái niệm',
    'YOLO thực hành (ultralytics)',
    'SSD, DETR lý thuyết',
    'mAP, IoU, NMS',
    'Augmentation & label cho detection',
    'Train YOLO dataset nhỏ',
    'Checkpoint',
  ]),
  w(29, 'P4 – Computer Vision', 'Segmentation', ['cv'], [
    'Segmentation: khái niệm',
    'U-Net kiến trúc',
    'IoU, Dice, loss segmentation',
    'Thực hành segmentation',
    'Hậu xử lý mask',
    'U-Net dataset nhỏ',
    'Checkpoint',
  ]),
  w(30, 'P4 – Computer Vision', 'GAN, CLIP, Diffusion', ['cv', 'multi'], [
    'GAN: generator/discriminator',
    'Self-supervised, CLIP',
    'Diffusion: trực giác toán',
    'Đánh giá ảnh sinh (FID/IS)',
    'Tổng ôn CV + flashcard',
    { t: 'Mô phỏng 6h bài CV', k: 'mock' },
    'Chữa bài + checkpoint',
  ]),
  w(31, 'P5 – NLP & Audio', 'NLP cổ điển', ['nlp'], [
    'NLP preprocessing, clean text',
    'Tokenization, vocab',
    'BoW, TF-IDF',
    'Text classification cổ điển',
    'Metrics NLP, phân tích lỗi',
    'Phân loại tin tức',
    'Checkpoint',
  ]),
  w(32, 'P5 – NLP & Audio', 'Embedding & RNN', ['nlp'], [
    'Word2Vec, GloVe',
    'RNN, hidden state',
    'LSTM, GRU',
    'Seq models thực hành',
    'Giới hạn RNN, vanishing gradient',
    'Sentiment với LSTM',
    'Checkpoint',
  ]),
  w(33, 'P5 – NLP & Audio', 'Transformer & BERT', ['nlp', 'attention'], [
    'Transformer cho NLP',
    'BERT, pretrained encoders',
    'HuggingFace pipeline',
    'Fine-tune phân loại văn bản',
    'Tokenizer nâng cao, subword',
    'Fine-tune BERT tiếng Việt',
    'Checkpoint',
  ]),
  w(34, 'P5 – NLP & Audio', 'Seq2seq & LLM', ['nlp'], [
    'Language modeling',
    'Encoder–decoder, seq2seq',
    'Machine translation',
    'Sinh văn bản, decoding',
    'API vs open-source model',
    'Dịch máy mini',
    'Checkpoint',
  ]),
  w(35, 'P5 – NLP & Audio', 'Audio', ['audio'], [
    'Audio: waveform, sample rate',
    'Mel-spectrogram, feature',
    'torchaudio, librosa',
    'Audio classification',
    'Whisper, HuBERT, Qwen-Audio',
    'ASR mini với Whisper',
    { t: 'Tổng ôn NLP+Audio + mock', k: 'mock' },
  ]),
  w(36, 'P6 – Multimodal', 'Vision-language & dữ liệu đa dạng', ['multi'], [
    'Vision-language, CLIP sâu',
    'VQA, image captioning',
    'Video: xử lý & mô hình',
    'Time-series cơ bản',
    'Pipeline đa phương thức',
    'Project CLIP retrieval',
    'Checkpoint',
  ]),
  w(37, 'P6 – Multimodal', 'Generative nâng cao', ['multi'], [
    'Diffusion sâu hơn (DDPM trực giác)',
    'GAN nâng cao',
    'Đánh giá mô hình sinh',
    'Giới hạn & rủi ro AI tạo sinh',
    'Tổng ôn generative',
    'Thử diffusers',
    'Checkpoint',
  ]),
  w(38, 'P6 – Multimodal', 'Đạo đức AI & tổng hợp', ['ethics', 'exam'], [
    'AI ethics: fairness, bias',
    'Privacy, safety, bản quyền',
    'Robustness, adversarial',
    'Ensembling, stacking',
    'Bảng so sánh toàn syllabus',
    'Case study ethics',
    { t: 'Mock tổng hợp 100 câu', k: 'mock' },
  ]),
  w(39, 'P7 – Nâng cao & Kaggle', 'Kaggle #1', ['exam', 'all'], [
    'Chọn Kaggle #1, đọc lỗi',
    'Baseline đơn giản',
    'EDA cho competition',
    'Feature cơ bản',
    'Submit đầu tiên',
    'Cải thiện CV/LB',
    'Tổng kết tuần 1',
  ]),
  w(40, 'P7 – Nâng cao & Kaggle', 'Kaggle #1 (tiếp)', ['exam', 'all'], [
    'Model 2, so sánh',
    'Cross-validation đúng cách',
    'Ensemble',
    'Viết báo cáo',
    'IOAI at-home tasks (nếu công bố)',
    'Cải thiện điểm',
    'Tổng kết Kaggle #1',
  ]),
  w(41, 'P7 – Nâng cao & Kaggle', 'Kaggle #2 (CV)', ['cv', 'exam'], [
    'Kaggle #2 (CV): chọn đề',
    'Pipeline ảnh nhanh',
    'Augmentation nâng cao',
    'Transfer learning',
    'TTA, ensemble',
    'Train & submit',
    'Review',
  ]),
  w(42, 'P7 – Nâng cao & Kaggle', 'Kaggle #2 (NLP/Audio)', ['nlp', 'audio', 'exam'], [
    'Kaggle #2 NLP/Audio',
    'Tokenize/feature nhanh',
    'Model & schedule',
    'Xử lý dữ liệu lớn',
    'Submit + theo dõi LB',
    'Cải thiện',
    'Review',
  ]),
  w(43, 'P7 – Nâng cao & Kaggle', 'Kỹ năng thi 6h', ['exam', 'all'], [
    'Kỹ năng đọc đề thi 6h',
    'Phân bổ thời gian, checkpoint',
    'Submission format, chống lỗi',
    'Kaggle #3 hoặc bài VAIO-style',
    'Tổng ôn',
    { t: 'Mô phỏng 3h', k: 'mock' },
    { t: 'Mô phỏng 6h', k: 'mock' },
  ]),
  w(44, 'P7 – Nâng cao & Kaggle', 'Mô phỏng CV 6h', ['cv', 'exam'], [
    'Mô phỏng CV 6h',
    'Chữa bài, ghi lỗi',
    'Tối ưu pipeline CV',
    'Toolkit: đoạn code tái dùng',
    'Tổng ôn',
    { t: 'Làm lại bài (rút ngắn)', k: 'mock' },
    'Ghi toolkit',
  ]),
  w(45, 'P7 – Nâng cao & Kaggle', 'Mô phỏng NLP 6h', ['nlp', 'exam'], [
    'Mô phỏng NLP 6h',
    'Chữa bài, ghi lỗi',
    'Tối ưu pipeline NLP',
    'Technical report mẫu',
    'Tổng ôn',
    { t: 'Làm lại bài', k: 'mock' },
    'Ghi toolkit',
  ]),
  w(46, 'P7 – Nâng cao & Kaggle', 'Mô phỏng Audio 6h', ['audio', 'exam'], [
    'Mô phỏng Audio 6h',
    'Chữa bài, ghi lỗi',
    'Tổng hợp lỗi toàn phase',
    'Hoàn thiện thư viện code',
    'Tổng ôn',
    { t: 'Làm lại bài', k: 'mock' },
    'Chốt toolkit 1.0',
  ]),
  w(47, 'P8 – VAIO Sprint', 'Sprint chủ đề 1–3', ['exam', 'all'], [
    'Ôn syllabus nhóm 1–3',
    'Quiz chủ đề 1',
    'Quiz chủ đề 2',
    'Quiz chủ đề 3',
    'Đọc lại câu sai',
    { t: 'Mock 120 phút', k: 'mock' },
    'Chữa đề; kiểm tra lịch đăng ký VAIO 2027',
  ]),
  w(48, 'P8 – VAIO Sprint', 'Sprint DL/CV', ['dl', 'cv', 'exam'], [
    'Sprint DL/CV',
    'Bảng so sánh thuật toán',
    'Quiz CV/DL',
    'Weak-area drills',
    'Flashcard API',
    { t: 'Mock 120 phút', k: 'mock' },
    'Chữa đề',
  ]),
  w(49, 'P8 – VAIO Sprint', 'Sprint NLP/Audio/Multimodal', ['nlp', 'audio', 'multi', 'exam'], [
    'Sprint NLP',
    'Sprint Audio',
    'Sprint Multimodal',
    'Flashcard API',
    'Quiz tổng',
    { t: 'Mock 120 phút', k: 'mock' },
    'Chữa đề',
  ]),
  w(50, 'P8 – VAIO Sprint', 'Sprint Toán & ML cổ điển', ['math-la', 'math-prob', 'ml-basics', 'exam'], [
    'Sprint Toán + ML cổ điển',
    'Đề cũ 2025',
    'Đề cũ 2026',
    'Weak-area drills',
    'Logistics dự thi',
    { t: 'Mock đầy đủ', k: 'mock' },
    'Chữa đề',
  ]),
  w(51, 'P8 – VAIO Sprint', 'Taper', ['exam', 'all'], [
    'Taper: flashcard nhẹ',
    'Quiz nhẹ 2 buổi',
    'Xem lại bảng công thức',
    'Chuẩn bị giấy tờ/địa điểm',
    'Ngủ đủ, không học mới',
    { t: 'Mock nhẹ', k: 'mock' },
    { t: 'Nghỉ ngơi', k: 'rest' },
  ]),
  w(52, 'P8 – VAIO Sprint', 'Tuần thi', ['exam', 'all'], [
    'Giữ nhịp, xem điểm yếu',
    'Ôn flashcard',
    'Quiz nhẹ',
    'Nghỉ sớm',
    'Kiểm tra giấy tờ lần cuối',
    { t: 'ĐI THI VAIO SƠ KHẢO (~17/10/2027)', k: 'exam' },
    { t: 'Ghi nhớ đề + nghỉ ngơi', k: 'rest' },
  ]),
];

function makeTasks(kind: DayKind, title: string): Task[] {
  switch (kind) {
    case 'lab':
      return [
        { type: 'review', label: 'Ôn spaced-repetition 20 câu', xp: 15, minutes: 20 },
        { type: 'lab', label: `Lab 4h: ${title}`, xp: 25, minutes: 120 },
        { type: 'note', label: 'Viết "bài học xương máu"', xp: 10, minutes: 15 },
        { type: 'lab', label: 'Cải thiện/tối ưu thêm 45 phút', xp: 10, minutes: 45 },
      ];
    case 'mock':
      return [
        { type: 'mock', label: `Mô phỏng có bấm giờ: ${title}`, xp: 0, minutes: 120 },
        { type: 'review', label: 'Chữa bài + ghi sổ lỗi', xp: 20, minutes: 60 },
        { type: 'note', label: 'Cập nhật bảng chống bẫy', xp: 10, minutes: 20 },
      ];
    case 'rest':
      return [
        { type: 'rest', label: 'Quiz nhanh 5 câu (giữ streak)', xp: 0, minutes: 5 },
        { type: 'rest', label: 'Nghỉ ngơi / ngủ đủ', xp: 0, minutes: 0 },
      ];
    case 'exam':
      return [
        { type: 'read', label: 'Chuẩn bị giấy tờ, dụng cụ, ngủ đủ', xp: 0, minutes: 20 },
        { type: 'exam', label: `ĐI THI: ${title}`, xp: 50, minutes: 180 },
        { type: 'note', label: 'Ghi nhớ đề ngay sau khi thi', xp: 10, minutes: 15 },
      ];
    case 'checkpoint':
      return [
        { type: 'review', label: 'Chữa đề & ôn tập', xp: 15, minutes: 30 },
        { type: 'mock', label: `Checkpoint: ${title}`, xp: 0, minutes: 30 },
        { type: 'note', label: 'Tổng kết tuần (5 câu hỏi)', xp: 10, minutes: 10 },
        { type: 'rest', label: 'Lên kế hoạch tuần sau', xp: 5, minutes: 10 },
      ];
    default:
      return [
        { type: 'read', label: `Lý thuyết: ${title}`, xp: 10, minutes: 20 },
        { type: 'code', label: `Code bài tập: ${title}`, xp: 15, minutes: 40 },
        { type: 'quiz', label: 'Quiz 10 câu (bắt buộc)', xp: 0, minutes: 15 },
        { type: 'note', label: 'Ghi chú 1 dòng', xp: 5, minutes: 5 },
      ];
  }
}

function kindForDay(dayIdx: number, override?: DayKind): DayKind {
  if (override) return override;
  if (dayIdx < 5) return 'lesson';
  if (dayIdx === 5) return 'lab';
  return 'checkpoint';
}

export const DAYS: DayPlan[] = WEEKS_RAW.flatMap((wk) =>
  wk.days.map((raw, i) => {
    const obj: RawDay = typeof raw === 'string' ? { t: raw } : raw;
    const index = (wk.week - 1) * 7 + i + 1;
    const kind = kindForDay(i, obj.k);
    return {
      id: `d${String(index).padStart(3, '0')}`,
      index,
      date: addDays(START_DATE, index - 1),
      week: wk.week,
      phase: wk.phase,
      theme: wk.theme,
      title: obj.t,
      kind,
      tags: wk.tags,
      tasks: makeTasks(kind, obj.t),
    } satisfies DayPlan;
  }),
);

export const WEEKS = WEEKS_RAW.map((wk) => ({
  week: wk.week,
  phase: wk.phase,
  theme: wk.theme,
  tags: wk.tags,
  days: DAYS.filter((d) => d.week === wk.week),
}));

export function dayByIndex(index: number): DayPlan {
  const clamped = Math.min(Math.max(index, 1), DAYS.length);
  return DAYS[clamped - 1];
}

export function dayById(id: string): DayPlan | undefined {
  return DAYS.find((d) => d.id === id);
}

export function dayForDate(dateISO: string): DayPlan {
  const idx = diffDays(START_DATE, dateISO) + 1;
  return dayByIndex(idx);
}

export const TOTAL_DAYS = DAYS.length;
