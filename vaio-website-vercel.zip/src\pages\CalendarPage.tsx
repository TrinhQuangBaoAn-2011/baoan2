import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { activityLevel } from '../lib/streak';
import { daysInMonth, formatVN, isoOfMonthDay, parseISO, todayISO, weekdayVN } from '../lib/dates';
import { DAYS } from '../data/curriculum';
import { Modal, Sticker } from '../components/ui';

const MONTH_NAMES = [
  'Tháng 1',
  'Tháng 2',
  'Tháng 3',
  'Tháng 4',
  'Tháng 5',
  'Tháng 6',
  'Tháng 7',
  'Tháng 8',
  'Tháng 9',
  'Tháng 10',
  'Tháng 11',
  'Tháng 12',
];

export default function CalendarPage() {
  const { snap, streak, toggleFreezeDay } = useApp();
  const today = todayISO();
  const now = parseISO(today);
  const [ym, setYm] = useState({ y: now.getFullYear(), m: now.getMonth() + 1 });
  const [selected, setSelected] = useState<string | null>(null);

  const cells = useMemo(() => {
    const firstDay = new Date(ym.y, ym.m - 1, 1).getDay(); // 0 = CN
    const lead = firstDay === 0 ? 6 : firstDay - 1; // thứ Hai đầu tuần
    const dim = daysInMonth(ym.y, ym.m);
    const out: { iso: string | null; day: number | null }[] = [];
    for (let i = 0; i < lead; i++) out.push({ iso: null, day: null });
    for (let d = 1; d <= dim; d++) out.push({ iso: isoOfMonthDay(ym.y, ym.m, d), day: d });
    while (out.length % 7 !== 0) out.push({ iso: null, day: null });
    return out;
  }, [ym]);

  function shift(delta: number) {
    let m = ym.m + delta;
    let y = ym.y;
    if (m < 1) {
      m = 12;
      y -= 1;
    }
    if (m > 12) {
      m = 1;
      y += 1;
    }
    setYm({ y, m });
  }

  const monthStats = useMemo(() => {
    let studied = 0;
    let minutes = 0;
    let xp = 0;
    for (const [date, a] of Object.entries(snap.activities)) {
      const d = parseISO(date);
      if (d.getFullYear() === ym.y && d.getMonth() + 1 === ym.m) {
        studied += 1;
        minutes += a.minutes;
        xp += a.xp;
      }
    }
    return { studied, minutes, xp };
  }, [snap.activities, ym]);

  const selActivity = selected ? snap.activities[selected] : undefined;
  const selFreeze = selected ? snap.freezes.includes(selected) : false;
  const selDays = useMemo(() => {
    if (!selected) return [];
    const ids = new Set<string>();
    for (const e of Object.values(snap.xpEvents)) {
      if (e.date === selected && e.source.startsWith('task:')) ids.add(e.source.slice(5));
    }
    for (const q of snap.quizzes) {
      if (q.startedAt.slice(0, 10) === selected) ids.add(q.dayId);
    }
    return DAYS.filter((d) => ids.has(d.id));
  }, [selected, snap.xpEvents, snap.quizzes]);

  return (
    <>
      <div className="grid cols-3">
        <div className="cal-main">
          <div className="card">
            <div className="row between">
              <button className="btn sm month-nav" onClick={() => shift(-1)} aria-label="Tháng trước">
                ‹
              </button>
              <h2 style={{ margin: 0 }}>
                {MONTH_NAMES[ym.m - 1]} {ym.y}
              </h2>
              <button className="btn sm month-nav" onClick={() => shift(1)} aria-label="Tháng sau">
                ›
              </button>
            </div>
            <div className="row between small muted" style={{ margin: '8px 0' }}>
              <span>Ô xanh = ngày đã học (đậm hơn = ngày học nhiều)</span>
              <span>Ô xanh dương = ngày dùng streak freeze</span>
            </div>
            <div className="cal-head">
              {['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'].map((d) => (
                <div key={d}>{d}</div>
              ))}
            </div>
            <div className="cal-grid">
              {cells.map((c, i) => {
                if (!c.iso) return <div key={i} className="cal-cell other" />;
                const lvl = activityLevel(snap.activities[c.iso]);
                const isFreeze = snap.freezes.includes(c.iso);
                const cls = [
                  'cal-cell',
                  isFreeze ? 'freeze' : lvl === 2 ? 'lvl-2' : lvl === 1 ? 'lvl-1' : '',
                  c.iso === today ? 'today' : '',
                ]
                  .filter(Boolean)
                  .join(' ');
                return (
                  <div key={i} className={cls} onClick={() => setSelected(c.iso)} title={c.iso}>
                    <div className="d">{c.day}</div>
                    {isFreeze ? <div className="tiny">🧊</div> : null}
                    {snap.activities[c.iso] ? (
                      <div className="tiny">{Math.round(snap.activities[c.iso].minutes)}'</div>
                    ) : null}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <div>
          <div className="card">
            <h3 className="card-title">
              <Sticker emoji="🔥" size="sm" /> Streak
            </h3>
            <div className="big-number">{streak.current} ngày</div>
            <div className="small muted">{streak.studiedToday ? 'Hôm nay đã học ✅' : 'Hôm nay chưa học'}</div>
            <div className="tiny muted" style={{ marginTop: 6 }}>
              Kỷ lục cá nhân: {streak.longest} ngày liên tiếp
            </div>
          </div>
          <div className="card">
            <h3>Tháng này</h3>
            <div className="small">
              📅 Đã học: <b>{monthStats.studied}</b> ngày
            </div>
            <div className="small">
              ⏱️ Thời lượng: <b>{Math.round(monthStats.minutes / 60)}</b> giờ
            </div>
            <div className="small">
              ⚡ XP kiếm được: <b>{monthStats.xp.toLocaleString('vi-VN')}</b>
            </div>
            <div className="tiny muted" style={{ marginTop: 8 }}>
              Bạn có tối đa 2 streak freeze mỗi tháng: đánh dấu ngày bận đột xuất để không đứt chuỗi.
            </div>
          </div>
          <div className="card">
            <h3>🧊 Freeze đã dùng</h3>
            <div className="small">{snap.freezes.length ? snap.freezes.map(formatVN).join(', ') : 'Chưa dùng ngày nào.'}</div>
          </div>
        </div>
      </div>

      {selected ? (
        <Modal onClose={() => setSelected(null)}>
          <h3 style={{ marginTop: 0 }}>
            {formatVN(selected)} · {weekdayVN(selected)}
          </h3>
          {selActivity ? (
            <div className="card" style={{ marginBottom: 10 }}>
              <div className="small">⏱️ {selActivity.minutes} phút học</div>
              <div className="small">⚡ {selActivity.xp} XP</div>
              <div className="small">
                ✅ {selActivity.tasks} nhiệm vụ · 🧠 {selActivity.quizzes} quiz
              </div>
            </div>
          ) : (
            <p className="small muted">Ngày này chưa có hoạt động học.</p>
          )}
          {selDays.length ? (
            <div style={{ marginBottom: 10 }}>
              <div className="small muted" style={{ marginBottom: 6 }}>
                Bài đã học trong ngày:
              </div>
              <div className="row">
                {selDays.map((d) => (
                  <Link key={d.id} className="badge blue day-chip" to={`/today?day=${d.id}`} onClick={() => setSelected(null)}>
                    Ngày {d.index} · {d.title}
                  </Link>
                ))}
              </div>
            </div>
          ) : null}
          <p className="tiny muted">
            Lịch học cuốn theo tiến độ, nên ngày thực không gắn cố định với một bài. Mở trang Hôm nay để học tiếp bài đang
            dở.
          </p>
          <div className="row">
            <Link className="btn primary sm" to="/today" onClick={() => setSelected(null)}>
              Mở ngày đang học
            </Link>
            <button className="btn sm" onClick={() => void toggleFreezeDay(selected)}>
              {selFreeze ? 'Bỏ freeze' : '🧊 Dùng freeze ngày này'}
            </button>
          </div>
        </Modal>
      ) : null}
    </>
  );
}
