import { describe, expect, it } from 'vitest';
import { DAYS, WEEKS } from './curriculum';
import { QUESTIONS, ALL_TAGS } from './questions';
import { REFS } from './refs';
import { REPOS, SNIPPETS } from './toolkit';

describe('dữ liệu lộ trình', () => {
  it('có đủ 52 tuần × 7 ngày = 364 ngày', () => {
    expect(WEEKS.length).toBe(52);
    expect(DAYS.length).toBe(364);
    expect(DAYS[0].date).toBe('2026-10-20');
    expect(DAYS[363].date).toBe('2027-10-18');
  });

  it('mỗi ngày đều có nhiệm vụ, id duy nhất, đủ 4 việc cho ngày học', () => {
    const ids = new Set(DAYS.map((d) => d.id));
    expect(ids.size).toBe(364);
    for (const d of DAYS) {
      expect(d.tasks.length).toBeGreaterThanOrEqual(2);
      if (d.kind === 'lesson') expect(d.tasks.length).toBe(4);
    }
  });

  it('mọi tag của tuần đều có câu hỏi trong ngân hàng (trừ all)', () => {
    const missing: string[] = [];
    for (const w of WEEKS) {
      for (const t of w.tags) {
        if (t === 'all') continue;
        if (!ALL_TAGS.includes(t)) missing.push(`tuần ${w.week}: ${t}`);
      }
    }
    expect(missing).toEqual([]);
  });
});

describe('ngân hàng câu hỏi', () => {
  it('id duy nhất và có giải thích', () => {
    const ids = new Set<string>();
    for (const q of QUESTIONS) {
      expect(ids.has(q.id)).toBe(false);
      ids.add(q.id);
      expect(q.why.length).toBeGreaterThan(5);
    }
    expect(QUESTIONS.length).toBeGreaterThanOrEqual(500);
  });

  it('đáp án trắc nghiệm nằm trong khoảng hợp lệ', () => {
    for (const q of QUESTIONS) {
      if (q.type === 'mcq') {
        expect(typeof q.a).toBe('number');
        expect(q.a as number).toBeGreaterThanOrEqual(0);
        expect(q.a as number).toBeLessThan(q.options?.length ?? 0);
      }
      if (q.type === 'multi') {
        const arr = q.a as number[];
        expect(arr.length).toBeGreaterThan(0);
        for (const i of arr) {
          expect(i).toBeGreaterThanOrEqual(0);
          expect(i).toBeLessThan(q.options?.length ?? 0);
        }
      }
      if (q.type === 'fill') {
        const arr = q.a as string[];
        expect(Array.isArray(arr)).toBe(true);
        expect(arr.length).toBeGreaterThan(0);
      }
    }
  });

  it('mỗi tuần có tối thiểu 8 câu liên quan để chơi quiz 10 câu', () => {
    const weak: string[] = [];
    for (const w of WEEKS) {
      const tags = w.tags.filter((t) => t !== 'all');
      const pool = tags.length ? QUESTIONS.filter((q) => q.tags.some((t) => tags.includes(t))) : QUESTIONS;
      if (pool.length < 8) weak.push(`tuần ${w.week} (${tags.join(', ')}): chỉ ${pool.length} câu`);
    }
    expect(weak).toEqual([]);
  });
});

describe('thư viện & toolkit', () => {
  it('có 50–120 tài liệu, link http(s), id duy nhất', () => {
    expect(REFS.length).toBeGreaterThanOrEqual(50);
    expect(REFS.length).toBeLessThanOrEqual(120);
    const ids = new Set(REFS.map((r) => r.id));
    expect(ids.size).toBe(REFS.length);
    for (const r of REFS) expect(r.url.startsWith('https://')).toBe(true);
  });

  it('repo GitHub đều là link https và có ghi chú', () => {
    expect(REPOS.length).toBeGreaterThanOrEqual(15);
    for (const r of REPOS) {
      expect(r.url.startsWith('https://github.com/')).toBe(true);
      expect(r.note.length).toBeGreaterThan(3);
    }
    expect(SNIPPETS.length).toBeGreaterThanOrEqual(6);
  });
});
