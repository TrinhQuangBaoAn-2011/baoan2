import { useRef, useState } from 'react';
import { useApp } from '../context/AppContext';
import { useAuth } from '../context/AuthContext';
import { todayISO, formatVN } from '../lib/dates';
import { Banner } from '../components/ui';

export default function SettingsPage() {
  const { snap, updateProfile, toggleFreezeDay, resetAll, importJson, exportJson, storeMode } = useApp();
  const auth = useAuth();
  const fileRef = useRef<HTMLInputElement>(null);
  const [confirmText, setConfirmText] = useState('');
  const [saved, setSaved] = useState(false);
  const [p, setP] = useState(snap.profile);

  async function saveProfile() {
    await updateProfile({
      name: p.name,
      startDate: p.startDate,
      dailyGoalMin: Number(p.dailyGoalMin) || 90,
      examDates: p.examDates,
    });
    setSaved(true);
    window.setTimeout(() => setSaved(false), 1500);
  }

  function download() {
    const blob = new Blob([exportJson()], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `vaio-backup-${todayISO()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  async function onFile(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (!f) return;
    const text = await f.text();
    await importJson(text);
    if (fileRef.current) fileRef.current.value = '';
  }

  const freezeToday = snap.freezes.includes(todayISO());
  const buildLabel = new Date(__BUILD_TIME__).toLocaleString('vi-VN', { dateStyle: 'medium', timeStyle: 'short' });

  return (
    <>
      <div className="card">
        <h2 style={{ marginTop: 0 }}>⚙️ Cài đặt</h2>
        <p className="muted small" style={{ marginTop: 0 }}>
          Tài khoản: <b>{auth.email}</b> ·{' '}
          {storeMode === 'supabase' ? (
            <span className="badge green">Supabase (đồng bộ nhiều thiết bị)</span>
          ) : (
            <span className="badge amber">Local (chỉ trình duyệt này)</span>
          )}{' '}
          <button className="btn sm ghost" onClick={() => void auth.signOut()}>
            Đăng xuất
          </button>
        </p>
        <p className="tiny muted" style={{ margin: 0 }}>
          Bản build: {buildLabel}
        </p>
      </div>

      <div className="grid cols-2">
        <div className="card">
          <h3>Hồ sơ & mục tiêu</h3>
          <label className="field">
            <span>Tên hiển thị</span>
            <input className="input" value={p.name} onChange={(e) => setP({ ...p, name: e.target.value })} />
          </label>
          <label className="field">
            <span>Ngày bắt đầu tính chuỗi (streak)</span>
            <input className="input" type="date" value={p.startDate} onChange={(e) => setP({ ...p, startDate: e.target.value })} />
          </label>
          <label className="field">
            <span>Mục tiêu phút/ngày thường</span>
            <input
              className="input"
              type="number"
              value={p.dailyGoalMin}
              onChange={(e) => setP({ ...p, dailyGoalMin: Number(e.target.value) })}
            />
          </label>
          <div className="row">
            <button className="btn primary" onClick={() => void saveProfile()}>
              {saved ? '✅ Đã lưu' : 'Lưu hồ sơ'}
            </button>
            <button className="btn" onClick={() => void toggleFreezeDay(todayISO())}>
              {freezeToday ? 'Bỏ freeze hôm nay' : `🧊 Dùng freeze hôm nay (${formatVN(todayISO())})`}
            </button>
          </div>
          <p className="tiny muted">
            Lịch học tự cuốn theo tiến độ: nghỉ một ngày thì bài vẫn ở đó, không bị nhảy. Ngày bắt đầu chỉ dùng để tính
            streak. Freeze giúp không đứt chuỗi khi ốm/bận đột xuất — tối đa 2 ngày mỗi tháng.
          </p>
        </div>

        <div className="card">
          <h3>Mốc thi cá nhân</h3>
          <label className="field">
            <span>VAIO sơ khảo (dự kiến)</span>
            <input
              className="input"
              type="date"
              value={p.examDates.vaio ?? ''}
              onChange={(e) => setP({ ...p, examDates: { ...p.examDates, vaio: e.target.value } })}
            />
          </label>
          <label className="field">
            <span>VOAI (dự kiến)</span>
            <input
              className="input"
              type="date"
              value={p.examDates.voai ?? ''}
              onChange={(e) => setP({ ...p, examDates: { ...p.examDates, voai: e.target.value } })}
            />
          </label>
          <label className="field">
            <span>IOAI (nếu được cử)</span>
            <input
              className="input"
              type="date"
              value={p.examDates.ioai ?? ''}
              onChange={(e) => setP({ ...p, examDates: { ...p.examDates, ioai: e.target.value } })}
            />
          </label>
          <label className="field">
            <span>IAIO (nếu được cử)</span>
            <input
              className="input"
              type="date"
              value={p.examDates.iaio ?? ''}
              onChange={(e) => setP({ ...p, examDates: { ...p.examDates, iaio: e.target.value } })}
            />
          </label>
          <button className="btn" onClick={() => void saveProfile()}>
            Lưu mốc thi
          </button>
        </div>
      </div>

      <div className="grid cols-2">
        <div className="card">
          <h3>💾 Sao lưu & phục hồi</h3>
          <p className="small muted">
            Tải file JSON chứa toàn bộ tiến độ (XP, quiz, streak, ghi chú) để đổi máy hoặc để phòng khi dữ liệu trình duyệt
            bị xoá.
          </p>
          <div className="row">
            <button className="btn primary" onClick={download}>
              ⬇ Tải bản sao lưu
            </button>
            <button className="btn" onClick={() => fileRef.current?.click()}>
              ⬆ Phục hồi từ file
            </button>
            <input ref={fileRef} type="file" accept="application/json,.json" style={{ display: 'none' }} onChange={onFile} />
          </div>
        </div>

        <div className="card">
          <h3>🗑️ Xoá toàn bộ dữ liệu</h3>
          <p className="small muted">
            Hành động này xoá XP, lịch sử quiz, streak, ghi chú (không thể hoàn tác). Gõ <b>XOA</b> để xác nhận.
          </p>
          <div className="row">
            <input className="input" style={{ maxWidth: 160 }} value={confirmText} onChange={(e) => setConfirmText(e.target.value)} placeholder="XOA" />
            <button
              className="btn danger"
              disabled={confirmText.trim().toUpperCase() !== 'XOA'}
              onClick={() => {
                void resetAll();
                setConfirmText('');
              }}
            >
              Xoá hết
            </button>
          </div>
        </div>
      </div>

      <div className="card">
        <h3>🔧 Bật chế độ đồng bộ Google thật (Supabase)</h3>
        {storeMode === 'supabase' ? (
          <Banner kind="info">
            Bạn đang chạy chế độ Supabase. Dữ liệu được lưu trên cloud và đồng bộ giữa điện thoại + máy tính sau khi đăng
            nhập cùng Gmail.
          </Banner>
        ) : (
          <Banner kind="warn">
            Hiện tại app chạy chế độ local. Làm lần lượt 5 bước dưới (khoảng 15 phút, một lần duy nhất) để bật đăng nhập
            Google thật và đồng bộ.
          </Banner>
        )}
        <ol className="small" style={{ paddingLeft: 20 }}>
          <li>
            Tạo project miễn phí tại <a href="https://supabase.com" target="_blank" rel="noreferrer">supabase.com</a> — chọn region
            Singapore.
          </li>
          <li>
            Mở <b>SQL Editor</b>, dán và chạy toàn bộ file <code>supabase/schema.sql</code> (có trong thư mục dự án). File này tạo
            bảng + khoá chống cộng trùng XP + chính sách RLS chỉ cho đúng email {auth.email || 'của bạn'}.
          </li>
          <li>
            Trên <a href="https://console.cloud.google.com" target="_blank" rel="noreferrer">Google Cloud Console</a>: tạo OAuth
            Client (Web application), thêm Authorized redirect URI:{' '}
            <code>https://&lt;project-ref&gt;.supabase.co/auth/v1/callback</code>. Giữ màn hình consent ở chế độ{' '}
            <b>Testing</b> và thêm test user <code>tqbaoan2k11@gmail.com</code>.
          </li>
          <li>
            Trong Supabase → Authentication → Providers → Google: dán Client ID/Secret vừa tạo. Ở Authentication → URL
            Configuration, thêm domain Vercel của bạn vào Redirect URLs.
          </li>
          <li>
            Tạo file <code>.env.local</code> (hoặc dán vào Environment Variables trên Vercel):
            <pre className="code">
{`VITE_SUPABASE_URL=https://<project-ref>.supabase.co
VITE_SUPABASE_ANON_KEY=<anon key>`}
            </pre>
            Sau đó build/deploy lại. App sẽ tự chuyển sang đăng nhập Google thật.
          </li>
        </ol>
        <p className="tiny muted" style={{ marginBottom: 0 }}>
          Bảo mật 2 lớp: consent screen chỉ cho test user + RLS trong database chỉ chấp nhận email{' '}
          <b>tqbaoan2k11@gmail.com</b>. Người khác đăng nhập Google vẫn không đọc/ghi được dữ liệu của bạn.
        </p>
      </div>

      <div className="card">
        <h3>🖥️ Chiến lược thiết bị: máy 4GB RAM, GPU yếu</h3>
        <p className="small">
          Bạn học trên nhiều thiết bị (máy tính 4GB RAM, GPU thấp + điện thoại). Quy tắc chia việc để không bao giờ bị
          chặn vì máy yếu:
        </p>
        <ul className="small" style={{ paddingLeft: 20 }}>
          <li>
            <b>Máy 4GB (chính):</b> lý thuyết, bài tập, quiz, EDA dữ liệu nhỏ–vừa, scikit-learn cỡ nhỏ, ghi chú. Cài Python
            64-bit + numpy/pandas/scikit-learn/matplotlib — <i>không cần</i> cài PyTorch bản CUDA nặng.
          </li>
          <li>
            <b>Google Colab (miễn phí, có GPU):</b> mọi bài deep learning từ tuần 20+ — CNN, transformer, fine-tune. Lưu
            bản sao notebook vào Google Drive. Lưu ý giới hạn phiên ~12h và GPU không được đảm bảo liên tục.
          </li>
          <li>
            <b>Kaggle Notebooks:</b> khoảng 30 giờ GPU/tuần, lưu version tự động, dataset có sẵn — dùng khi Colab hết
            quota hoặc bài cần dataset lớn.
          </li>
          <li>
            <b>Điện thoại:</b> quiz hằng ngày, đọc thư viện, tick checklist (bật Supabase là dữ liệu đồng bộ giữa các
            máy).
          </li>
        </ul>
        <p className="small muted">
          Mẹo tiết kiệm RAM local: ép kiểu <code>category</code> cho cột chuỗi lặp, đọc CSV theo <code>chunksize</code>,
          <code>del</code> + <code>gc.collect()</code> sau khi dùng xong — xem snippet <b>s9</b> ở trang Toolkit. Nếu chỉ
          muốn chạy thử PyTorch trên máy: cài bản CPU bằng{' '}
          <code>pip install torch --index-url https://download.pytorch.org/whl/cpu</code>.
        </p>
        <p className="small muted" style={{ marginBottom: 0 }}>
          Phòng thi IOAI/VAIO cấp máy có GPU sẵn — khi luyện trên Colab hãy tập thói quen viết code theo biến{' '}
          <code>device = &quot;cuda&quot; if torch.cuda.is_available() else &quot;cpu&quot;</code> để chạy được ở cả hai
          nơi.
        </p>
      </div>
    </>
  );
}
