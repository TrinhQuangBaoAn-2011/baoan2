import type { Snapshot } from '../types';
import type { Ops } from '../mutations';

export interface Store {
  mode: 'local' | 'supabase';
  load(): Promise<Snapshot>;
  /** Ghi các thay đổi (ops) xuống nơi lưu trữ. */
  persist(snap: Snapshot, ops: Ops): Promise<void>;
  /** Xoá sạch dữ liệu, trả về snapshot mặc định. */
  reset(): Promise<Snapshot>;
  importSnapshot(snap: Snapshot): Promise<Snapshot>;
}
