import { DAYS } from '../data/curriculum';
import type { DayPlan, Snapshot } from './types';

const QUIZ_KINDS = new Set(['daily', 'fast']);

export function quizDaySet(snap: Snapshot): Set<string> {
  return new Set(snap.quizzes.filter((q) => QUIZ_KINDS.has(q.kind)).map((q) => q.dayId));
}

export function hasDayQuiz(snap: Snapshot, dayId: string): boolean {
  return snap.quizzes.some((q) => q.dayId === dayId && QUIZ_KINDS.has(q.kind));
}

export function dayDoneCount(snap: Snapshot, day: DayPlan, quizDays?: Set<string>): number {
  const done = snap.tasks[day.id] ?? [];
  const quizDone = quizDays ? quizDays.has(day.id) : hasDayQuiz(snap, day.id);
  return day.tasks.filter((t, i) => (t.type === 'quiz' ? quizDone : done.includes(i))).length;
}

export function isDayComplete(snap: Snapshot, day: DayPlan, quizDays?: Set<string>): boolean {
  return day.tasks.length > 0 && dayDoneCount(snap, day, quizDays) === day.tasks.length;
}

/** Ngày đầu tiên chưa hoàn thành; cả lộ trình xong thì trả về ngày cuối. */
export function currentDayOf(snap: Snapshot): DayPlan {
  const quizDays = quizDaySet(snap);
  return DAYS.find((day) => !isDayComplete(snap, day, quizDays)) ?? DAYS[DAYS.length - 1];
}

export function isPlanComplete(snap: Snapshot, last = currentDayOf(snap)): boolean {
  return last.id === DAYS[DAYS.length - 1].id && isDayComplete(snap, last);
}
