import { spawnSync } from 'node:child_process';
import { copyFileSync, cpSync, existsSync, mkdirSync, readdirSync, rmSync, statSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const dist = join(root, 'dist');
const deployDir = process.env.VAIO_DEPLOY_DIR || resolve(root, '..', 'DEPLOY VAIO');

function fail(message) {
  console.error(`\n❌ ${message}`);
  process.exit(1);
}

function run(command, args, options = {}) {
  const isWindows = process.platform === 'win32';
  const result = spawnSync(
    isWindows ? 'cmd.exe' : command,
    isWindows ? ['/d', '/s', '/c', [command, ...args].join(' ')] : args,
    {
      cwd: root,
      stdio: 'inherit',
      ...options,
    },
  );
  if (result.status !== 0) fail(`Lệnh thất bại: ${command} ${args.join(' ')}`);
}

function zipFolder(stage, destination) {
  const quote = (value) => `'${value.replace(/'/g, "''")}'`;
  const script = `$ProgressPreference='SilentlyContinue'; Compress-Archive -Path ${quote(join(stage, '*'))} -DestinationPath ${quote(destination)} -Force`;
  const encoded = Buffer.from(script, 'utf16le').toString('base64');
  run('powershell.exe', ['-NoProfile', '-NonInteractive', '-EncodedCommand', encoded]);
}

function countFiles(dir) {
  return readdirSync(dir, { withFileTypes: true }).reduce(
    (total, entry) => total + (entry.isDirectory() ? countFiles(join(dir, entry.name)) : 1),
    0,
  );
}

console.log('🔨 Đang build...');
run(process.platform === 'win32' ? 'npm.cmd' : 'npm', ['run', 'build'], {
  env: { ...process.env, NODE_OPTIONS: process.env.NODE_OPTIONS || '--max-old-space-size=1536' },
});

if (!existsSync(join(dist, 'index.html'))) fail('Không thấy dist/index.html sau khi build.');

const now = new Date();
const pad = (value) => String(value).padStart(2, '0');
const stamp = `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}-${pad(now.getHours())}${pad(now.getMinutes())}`;
const stage = join(tmpdir(), `vaio-static-${stamp}`);

try {
  rmSync(stage, { recursive: true, force: true });
  mkdirSync(stage, { recursive: true });
  cpSync(dist, stage, { recursive: true });
  copyFileSync(join(root, 'vercel.json'), join(stage, 'vercel.json'));

  mkdirSync(deployDir, { recursive: true });
  const stable = join(deployDir, 'vaio-website-static.zip');
  const versioned = join(deployDir, `vaio-website-static-${stamp}.zip`);

  zipFolder(stage, versioned);
  copyFileSync(versioned, stable);

  const files = countFiles(stage);
  const size = Math.round(statSync(stable).size / 1024);
  console.log(`\n✅ Xong: ${stable}`);
  console.log(`   ${files} file · ${size} KB · bản lưu: ${versioned}`);
} finally {
  rmSync(stage, { recursive: true, force: true });
}
