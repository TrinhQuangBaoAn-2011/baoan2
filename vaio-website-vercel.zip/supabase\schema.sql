-- ============================================================
-- Roadmap VAIO/IOAI — Supabase schema
-- Cách dùng: Supabase → SQL Editor → dán toàn bộ file này → Run.
-- Nguyên tắc:
--   1) Mọi bảng đều có khoá chính ghép (user_id, ...) để chống ghi trùng.
--      XP nằm ở bảng xp_events với event_key duy nhất => không thể cộng điểm ảo.
--   2) RLS chỉ cho đúng 1 email truy cập (kiểm tra ở cả JWT email lẫn auth.uid()).
-- ============================================================

-- ---------- Bảng ----------
create table if not exists profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  name text default 'Bảo An',
  start_date date default '2026-10-20',
  exam_dates jsonb default '{}'::jsonb,
  daily_goal_min int default 90,
  updated_at timestamptz default now()
);

create table if not exists task_progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  day_id text not null,
  task_index int not null,
  completed_at timestamptz default now(),
  primary key (user_id, day_id, task_index)
);

create table if not exists xp_events (
  user_id uuid not null references auth.users(id) on delete cascade,
  event_key text not null,
  amount int not null,
  event_date date not null,
  source text,
  created_at timestamptz default now(),
  primary key (user_id, event_key)
);

create table if not exists quiz_sessions (
  id uuid primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  day_id text,
  kind text,
  started_at timestamptz,
  finished_at timestamptz,
  score int default 0,
  total int default 0,
  tags text[] default '{}',
  details jsonb default '[]'::jsonb
);

create table if not exists review_queue (
  user_id uuid not null references auth.users(id) on delete cascade,
  question_id text not null,
  due_date date not null,
  interval_idx int default 0,
  wrong int default 0,
  last text,
  primary key (user_id, question_id)
);

create table if not exists ref_progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  ref_id text not null,
  status text default 'todo',
  note text default '',
  updated_at timestamptz default now(),
  primary key (user_id, ref_id)
);

create table if not exists activities (
  user_id uuid not null references auth.users(id) on delete cascade,
  activity_date date not null,
  xp int default 0,
  minutes int default 0,
  tasks int default 0,
  quizzes int default 0,
  primary key (user_id, activity_date)
);

create table if not exists freezes (
  user_id uuid not null references auth.users(id) on delete cascade,
  freeze_date date not null,
  primary key (user_id, freeze_date)
);

create table if not exists mock_exams (
  id text primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  title text,
  taken_at date,
  duration_min int default 0,
  score int default 0,
  total int default 1,
  notes text default ''
);

-- ---------- Row Level Security: chỉ tài khoản chủ sở hữu + đúng email ----------
do $$
declare
  t text;
  allowed text := 'tqbaoan2k11@gmail.com';
begin
  foreach t in array array[
    'profiles', 'task_progress', 'xp_events', 'quiz_sessions',
    'review_queue', 'ref_progress', 'activities', 'freezes', 'mock_exams'
  ]
  loop
    execute format('alter table %I enable row level security', t);
    execute format('drop policy if exists own_rows on %I', t);
    execute format(
      'create policy own_rows on %I for all to authenticated '
      || 'using (auth.uid() = user_id and lower(auth.jwt() ->> ''email'') = %L) '
      || 'with check (auth.uid() = user_id and lower(auth.jwt() ->> ''email'') = %L)',
      t, allowed, allowed
    );
  end loop;
end $$;

-- ---------- Gợi ý kiểm tra nhanh sau khi đăng nhập app lần đầu ----------
-- select * from profiles;
-- select sum(amount) as total_xp from xp_events;
-- select * from activities order by activity_date desc limit 7;
