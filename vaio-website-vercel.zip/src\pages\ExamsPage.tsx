import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { diffDays, formatVN, todayISO } from '../lib/dates';
import type { MockExam } from '../lib/types';

const MILESTONES = [
  { id: 'voai', title: 'VOAI 2027 (sơ khảo ~3–4/2027)', date: '2027-04-01', note: 'Cần trường/Sở giới thiệu → nếu đỗ sẽ dự IOAI 2027 tại Singapore (4–10/7/2027). Liên hệ thầy cô ngay từ học kỳ 1.' },
  { id: 'iaio', title: 'IAIO 2027 — Đà Nẵng (25/2–2/3/2027)', date: '2027-02-25', note: 'Đội tuyển Việt Nam dự IAIO (không phải kỳ thi tự do). Theo dõi iaio.vn để biết thông tin đội tuyển.' },
  { id: 'ioai', title: 'IOAI 2027 — Singapore (4–10/7/2027)', date: '2027-07-04', note: 'Đích chính của lộ trình. 2 ngày thi, mỗi ngày 6 giờ, đội tối đa 4 học sinh.' },
  { id: 'vaio-reg', title: 'VAIO 2027 — mở đăng ký (~9/2027)', date: '2027-09-01', note: 'Theo dõi iaio.vn/vaio hàng tuần từ tháng 8/2027. Đăng ký ngay khi mở.' },
  { id: 'vaio', title: 'VAIO 2027 — sơ khảo (~10/2027)', date: '2027-10-17', note: '120 phút, trắc nghiệm song ngữ, top 100 → chung kết (~1/2028) → chọn đội dự IAIO 2028.' },
];

export default function ExamsPage() {
  const { snap, recordMock } = useApp();
  const today = todayISO();
  const [form, setForm] = useState({ title: '', takenAt: today, durationMin: 120, score: 0, total: 100, notes: '' });

  const sorted = [...MILESTONES].sort((a, b) => a.date.localeCompare(b.date));

  function addMock(e: React.FormEvent) {
    e.preventDefault();
    const m: MockExam = {
      id: `m-${Date.now()}`,
      title: form.title || 'Mock không tên',
      takenAt: form.takenAt,
      durationMin: Number(form.durationMin) || 0,
      score: Number(form.score) || 0,
      total: Number(form.total) || 1,
      notes: form.notes,
    };
    void recordMock(m);
    setForm({ ...form, title: '', score: 0, notes: '' });
  }

  return (
    <>
      <div className="card">
        <h2 style={{ marginTop: 0 }}>🏁 Mốc thi & đếm ngược</h2>
        <p className="muted small" style={{ marginTop: 0 }}>
          Đây là mốc <b>tham khảo</b>, không phải deadline của lịch học: bài học tự cuốn theo tiến độ, nghỉ một ngày thì
          bài vẫn ở đó. Ngày sơ khảo/chung kết có thể xê dịch — luôn kiểm tra lại iaio.vn và olp.vn.
        </p>
        <div className="grid cols-2">
          {sorted.map((m) => {
            const left = diffDays(today, m.date);
            return (
              <div key={m.id} className="card" style={{ marginBottom: 0 }}>
                <b>{m.title}</b>
                <div className="small muted">{formatVN(m.date)}</div>
                <div style={{ fontSize: 26, fontWeight: 800, margin: '4px 0' }}>
                  {left > 0 ? `còn ${left} ngày` : left === 0 ? 'HÔM NAY' : `đã qua ${-left} ngày`}
                </div>
                <div className="tiny muted">{m.note}</div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="grid cols-2">
        <div className="card">
          <h3>Phòng mô phỏng</h3>
          <p className="small muted">
            Mô phỏng đúng áp lực: bấm giờ, không hiện đáp án, nộp bài mới biết điểm. Sau mỗi lần nhớ ghi lại vào bảng bên
            cạnh.
          </p>
          <div className="row">
            <Link className="btn primary" to="/quiz?mode=mock">
              Vào phòng mô phỏng
            </Link>
            <Link className="btn" to="/quiz">
              Chọn chế độ khác
            </Link>
          </div>
          <div className="tiny muted" style={{ marginTop: 8 }}>
            Gợi ý lịch: tuần 43–46 mô phỏng CV/NLP/Audio; tuần 47–50 mock 120 phút mỗi tuần 2–3 lần.
          </div>
        </div>

        <div className="card">
          <h3>✅ Checklist trước ngày thi</h3>
          <ul className="small" style={{ margin: 0, paddingLeft: 18 }}>
            <li>Đọc kỹ thông báo chính thức (thời gian, địa điểm, thiết bị được mang).</li>
            <li>Ngủ đủ 7–8 tiếng; không học nội dung mới trong 48 giờ cuối.</li>
            <li>Chuẩn bị CCCD/giấy tờ tuỳ thân + bút + nước (theo quy định BTC).</li>
            <li>Làm thử 1 đề ngắn làm “khởi động tay” buổi sáng.</li>
            <li>Đến sớm 30 phút; kiểm tra máy/tài khoản tham gia nếu thi online.</li>
          </ul>
        </div>
      </div>

      <div className="card">
        <h3>📋 Ghi lại các lần mô phỏng / thi thật</h3>
        <form onSubmit={addMock} className="grid cols-4">
          <label className="field">
            <span>Tên bài</span>
            <input className="input" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Mock CV 6h" />
          </label>
          <label className="field">
            <span>Ngày làm</span>
            <input className="input" type="date" value={form.takenAt} onChange={(e) => setForm({ ...form, takenAt: e.target.value })} />
          </label>
          <label className="field">
            <span>Thời gian (phút)</span>
            <input className="input" type="number" value={form.durationMin} onChange={(e) => setForm({ ...form, durationMin: Number(e.target.value) })} />
          </label>
          <label className="field">
            <span>Điểm / Tổng</span>
            <div className="row">
              <input className="input" type="number" value={form.score} onChange={(e) => setForm({ ...form, score: Number(e.target.value) })} />
              <input className="input" type="number" value={form.total} onChange={(e) => setForm({ ...form, total: Number(e.target.value) })} />
            </div>
          </label>
          <label className="field" style={{ gridColumn: 'span 3' }}>
            <span>Bài học sau khi làm</span>
            <input className="input" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="Lỗi hay gặp: quên seed, pipeline chậm…" />
          </label>
          <div style={{ display: 'flex', alignItems: 'flex-end' }}>
            <button className="btn primary" style={{ width: '100%' }}>
              + Lưu
            </button>
          </div>
        </form>

        {snap.mocks.length ? (
          <table style={{ marginTop: 12 }}>
            <thead>
              <tr>
                <th>Ngày</th>
                <th>Bài</th>
                <th>Thời gian</th>
                <th>Điểm</th>
                <th>Ghi chú</th>
              </tr>
            </thead>
            <tbody>
              {snap.mocks.map((m) => (
                <tr key={m.id}>
                  <td>{formatVN(m.takenAt.slice(0, 10))}</td>
                  <td>{m.title}</td>
                  <td>{m.durationMin}′</td>
                  <td>
                    <b>{m.score}</b>/{m.total} ({Math.round((m.score / Math.max(1, m.total)) * 100)}%)
                  </td>
                  <td className="small muted">{m.notes}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p className="muted small">Chưa có lần mô phỏng nào được ghi.</p>
        )}
      </div>
    </>
  );
}
