import type { SupabaseClient } from '@supabase/supabase-js';
import type {
  Activity,
  MockExam,
  Profile,
  QuizSession,
  RefProgress,
  ReviewItem,
  Snapshot,
  XpEvent,
} from '../types';
import type { Ops } from '../mutations';
import { defaultSnapshot } from '../mutations';
import type { Store } from './types';

const TABLES = [
  'task_progress',
  'xp_events',
  'quiz_sessions',
  'review_queue',
  'ref_progress',
  'activities',
  'freezes',
  'mock_exams',
] as const;

function fail(results: { error: unknown }[]) {
  const bad = results.find((r) => r.error);
  if (bad) {
    const msg = (bad.error as { message?: string })?.message ?? String(bad.error);
    throw new Error(`Supabase: ${msg}. Bạn đã chạy file supabase/schema.sql chưa?`);
  }
}

export function createSupabaseStore(sb: SupabaseClient, userId: string, email: string): Store {
  async function wipe() {
    const res = await Promise.all(TABLES.map((t) => sb.from(t).delete().eq('user_id', userId)));
    fail(res);
  }

  async function load(): Promise<Snapshot> {
    const [p, tp, xe, qs, rq, rp, ac, fr, mk] = await Promise.all([
      sb.from('profiles').select('*').eq('user_id', userId).maybeSingle(),
      sb.from('task_progress').select('*').eq('user_id', userId),
      sb.from('xp_events').select('*').eq('user_id', userId),
      sb.from('quiz_sessions').select('*').eq('user_id', userId).order('started_at', { ascending: false }).limit(1000),
      sb.from('review_queue').select('*').eq('user_id', userId),
      sb.from('ref_progress').select('*').eq('user_id', userId),
      sb.from('activities').select('*').eq('user_id', userId),
      sb.from('freezes').select('*').eq('user_id', userId),
      sb.from('mock_exams').select('*').eq('user_id', userId).order('taken_at', { ascending: false }).limit(200),
    ]);
    fail([p, tp, xe, qs, rq, rp, ac, fr, mk]);

    const snap = defaultSnapshot(email);
    if (p.data) {
      const row = p.data as Record<string, unknown>;
      snap.profile = {
        ...snap.profile,
        email,
        name: (row.name as string) ?? snap.profile.name,
        startDate: (row.start_date as string) ?? snap.profile.startDate,
        examDates: (row.exam_dates as Profile['examDates']) ?? snap.profile.examDates,
        dailyGoalMin: (row.daily_goal_min as number) ?? snap.profile.dailyGoalMin,
      };
    }
    for (const r of (tp.data ?? []) as Record<string, unknown>[]) {
      const dayId = r.day_id as string;
      const idx = r.task_index as number;
      snap.tasks[dayId] = [...(snap.tasks[dayId] ?? []), idx].sort((a, b) => a - b);
    }
    for (const r of (xe.data ?? []) as Record<string, unknown>[]) {
      const key = r.event_key as string;
      snap.xpEvents[key] = { key, amount: r.amount as number, date: r.event_date as string, source: r.source as string };
    }
    snap.quizzes = ((qs.data ?? []) as Record<string, unknown>[]).map((r) => ({
      id: r.id as string,
      dayId: r.day_id as string,
      kind: r.kind as QuizSession['kind'],
      startedAt: r.started_at as string,
      finishedAt: r.finished_at as string,
      score: r.score as number,
      total: r.total as number,
      tags: (r.tags as string[]) ?? [],
      details: (r.details as QuizSession['details']) ?? [],
    }));
    for (const r of (rq.data ?? []) as Record<string, unknown>[]) {
      snap.review[r.question_id as string] = {
        due: r.due_date as string,
        intervalIdx: r.interval_idx as number,
        wrong: r.wrong as number,
        last: r.last as ReviewItem['last'],
      };
    }
    for (const r of (rp.data ?? []) as Record<string, unknown>[]) {
      snap.refs[r.ref_id as string] = {
        status: r.status as RefProgress['status'],
        note: (r.note as string) ?? '',
        updatedAt: (r.updated_at as string) ?? '',
      };
    }
    for (const r of (ac.data ?? []) as Record<string, unknown>[]) {
      const date = r.activity_date as string;
      snap.activities[date] = {
        date,
        xp: r.xp as number,
        minutes: r.minutes as number,
        tasks: r.tasks as number,
        quizzes: r.quizzes as number,
      } satisfies Activity;
    }
    snap.freezes = ((fr.data ?? []) as Record<string, unknown>[]).map((r) => r.freeze_date as string).sort();
    snap.mocks = ((mk.data ?? []) as Record<string, unknown>[]).map((r) => ({
      id: r.id as string,
      title: r.title as string,
      takenAt: r.taken_at as string,
      durationMin: r.duration_min as number,
      score: r.score as number,
      total: r.total as number,
      notes: (r.notes as string) ?? '',
    }));
    return snap;
  }

  async function persist(snap: Snapshot, ops: Ops) {
    const jobs: PromiseLike<{ error: unknown }>[] = [];
    const push = (p: PromiseLike<{ error: unknown }>) => {
      jobs.push(p);
    };

    if (ops.task) {
      const { dayId, taskIndex, done } = ops.task;
      const p = done
        ? sb.from('task_progress').upsert(
            { user_id: userId, day_id: dayId, task_index: taskIndex, completed_at: new Date().toISOString() },
            { onConflict: 'user_id,day_id,task_index' },
          )
        : sb.from('task_progress').delete().eq('user_id', userId).eq('day_id', dayId).eq('task_index', taskIndex);
      push(p as unknown as PromiseLike<{ error: unknown }>);
    }
    for (const key of ops.xpKeys) {
      const ev = snap.xpEvents[key] as XpEvent | undefined;
      const p = ev
        ? sb.from('xp_events').upsert(
            { user_id: userId, event_key: ev.key, amount: ev.amount, event_date: ev.date, source: ev.source },
            { onConflict: 'user_id,event_key' },
          )
        : sb.from('xp_events').delete().eq('user_id', userId).eq('event_key', key);
      push(p as unknown as PromiseLike<{ error: unknown }>);
    }
    for (const date of ops.activityDates) {
      const a = snap.activities[date];
      const p = a
        ? sb.from('activities').upsert(
            { user_id: userId, activity_date: a.date, xp: a.xp, minutes: a.minutes, tasks: a.tasks, quizzes: a.quizzes },
            { onConflict: 'user_id,activity_date' },
          )
        : sb.from('activities').delete().eq('user_id', userId).eq('activity_date', date);
      push(p as unknown as PromiseLike<{ error: unknown }>);
    }
    if (ops.quizzes.length) {
      const rows = ops.quizzes.map((q) => ({
        id: q.id,
        user_id: userId,
        day_id: q.dayId,
        kind: q.kind,
        started_at: q.startedAt,
        finished_at: q.finishedAt,
        score: q.score,
        total: q.total,
        tags: q.tags,
        details: q.details,
      }));
      push(sb.from('quiz_sessions').upsert(rows, { onConflict: 'id' }) as unknown as PromiseLike<{ error: unknown }>);
    }
    for (const qid of ops.reviewChanged) {
      const r = snap.review[qid];
      const p = r
        ? sb.from('review_queue').upsert(
            { user_id: userId, question_id: qid, due_date: r.due, interval_idx: r.intervalIdx, wrong: r.wrong, last: r.last },
            { onConflict: 'user_id,question_id' },
          )
        : sb.from('review_queue').delete().eq('user_id', userId).eq('question_id', qid);
      push(p as unknown as PromiseLike<{ error: unknown }>);
    }
    for (const id of ops.refsChanged) {
      const r = snap.refs[id];
      const p = r
        ? sb.from('ref_progress').upsert(
            { user_id: userId, ref_id: id, status: r.status, note: r.note, updated_at: r.updatedAt },
            { onConflict: 'user_id,ref_id' },
          )
        : sb.from('ref_progress').delete().eq('user_id', userId).eq('ref_id', id);
      push(p as unknown as PromiseLike<{ error: unknown }>);
    }
    for (const date of ops.freezesChanged) {
      const on = snap.freezes.includes(date);
      const p = on
        ? sb.from('freezes').upsert({ user_id: userId, freeze_date: date }, { onConflict: 'user_id,freeze_date' })
        : sb.from('freezes').delete().eq('user_id', userId).eq('freeze_date', date);
      push(p as unknown as PromiseLike<{ error: unknown }>);
    }
    if (ops.profileChanged) {
      const pr = snap.profile;
      push(
        sb
          .from('profiles')
          .upsert(
            {
              user_id: userId,
              email,
              name: pr.name,
              start_date: pr.startDate,
              exam_dates: pr.examDates,
              daily_goal_min: pr.dailyGoalMin,
            },
            { onConflict: 'user_id' },
          ) as unknown as PromiseLike<{ error: unknown }>,
      );
    }
    if (ops.mocks.length) {
      const rows = ops.mocks.map((m) => ({
        id: m.id,
        user_id: userId,
        title: m.title,
        taken_at: m.takenAt,
        duration_min: m.durationMin,
        score: m.score,
        total: m.total,
        notes: m.notes,
      }));
      push(sb.from('mock_exams').upsert(rows, { onConflict: 'id' }) as unknown as PromiseLike<{ error: unknown }>);
    }

    const resolved = await Promise.all(jobs);
    fail(resolved);
  }

  async function bulkInsert(snap: Snapshot) {
    const jobs: PromiseLike<{ error: unknown }>[] = [];
    const push = (p: unknown) => jobs.push(p as PromiseLike<{ error: unknown }>);

    push(
      sb.from('profiles').upsert(
        {
          user_id: userId,
          email,
          name: snap.profile.name,
          start_date: snap.profile.startDate,
          exam_dates: snap.profile.examDates,
          daily_goal_min: snap.profile.dailyGoalMin,
        },
        { onConflict: 'user_id' },
      ),
    );
    const taskRows = Object.entries(snap.tasks).flatMap(([dayId, idxs]) =>
      idxs.map((i) => ({ user_id: userId, day_id: dayId, task_index: i, completed_at: new Date().toISOString() })),
    );
    if (taskRows.length) push(sb.from('task_progress').upsert(taskRows, { onConflict: 'user_id,day_id,task_index' }));
    const xpRows = Object.values(snap.xpEvents).map((e) => ({
      user_id: userId,
      event_key: e.key,
      amount: e.amount,
      event_date: e.date,
      source: e.source,
    }));
    if (xpRows.length) push(sb.from('xp_events').upsert(xpRows, { onConflict: 'user_id,event_key' }));
    if (snap.quizzes.length)
      push(
        sb.from('quiz_sessions').upsert(
          snap.quizzes.map((q) => ({
            id: q.id,
            user_id: userId,
            day_id: q.dayId,
            kind: q.kind,
            started_at: q.startedAt,
            finished_at: q.finishedAt,
            score: q.score,
            total: q.total,
            tags: q.tags,
            details: q.details,
          })),
          { onConflict: 'id' },
        ),
      );
    const reviewRows = Object.entries(snap.review).map(([qid, r]) => ({
      user_id: userId,
      question_id: qid,
      due_date: r.due,
      interval_idx: r.intervalIdx,
      wrong: r.wrong,
      last: r.last,
    }));
    if (reviewRows.length) push(sb.from('review_queue').upsert(reviewRows, { onConflict: 'user_id,question_id' }));
    const refRows = Object.entries(snap.refs).map(([id, r]) => ({
      user_id: userId,
      ref_id: id,
      status: r.status,
      note: r.note,
      updated_at: r.updatedAt,
    }));
    if (refRows.length) push(sb.from('ref_progress').upsert(refRows, { onConflict: 'user_id,ref_id' }));
    const actRows = Object.values(snap.activities).map((a) => ({
      user_id: userId,
      activity_date: a.date,
      xp: a.xp,
      minutes: a.minutes,
      tasks: a.tasks,
      quizzes: a.quizzes,
    }));
    if (actRows.length) push(sb.from('activities').upsert(actRows, { onConflict: 'user_id,activity_date' }));
    const freezeRows = snap.freezes.map((d) => ({ user_id: userId, freeze_date: d }));
    if (freezeRows.length) push(sb.from('freezes').upsert(freezeRows, { onConflict: 'user_id,freeze_date' }));
    if (snap.mocks.length)
      push(
        sb.from('mock_exams').upsert(
          snap.mocks.map((m) => ({
            id: m.id,
            user_id: userId,
            title: m.title,
            taken_at: m.takenAt,
            duration_min: m.durationMin,
            score: m.score,
            total: m.total,
            notes: m.notes,
          })),
          { onConflict: 'id' },
        ),
      );
    const resolved = await Promise.all(jobs);
    fail(resolved);
  }

  return {
    mode: 'supabase',
    load,
    persist,
    async reset() {
      await wipe();
      const snap = defaultSnapshot(email);
      await bulkInsert(snap);
      return snap;
    },
    async importSnapshot(snap: Snapshot) {
      await wipe();
      await bulkInsert(snap);
      return snap;
    },
  };
}
